import winston, {format} from 'winston';

const Logger = winston.createLogger({
  format: format.combine(
    format.splat(),
    format.simple(),    
    format.colorize(),
  ),    
  transports: [
    new winston.transports.Console({
      level: process.env.LOG_LEVEL || 'debug',
      timestamp: true,
      showLevel: true,
    }),
  ],
});

export default Logger;