import { encode, decode } from "base-64";
import utf8 from "utf8";
import { getCookie } from '../../../components/doc-mgmt-app/sso/SingleSignOn';

import { WS_REGION, WS_LEG } from '../../../components/constants/GlobalConstants';
import XMLParser from "xml-js";


function getData(responseXML) {
  var responseObject = {
    reviewCaseStr: '',
    jobMessages: []
  };

  console.log(responseXML);
  let response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
  var jsonResponse = JSON.parse(response);
  let data = jsonResponse["reviewCase"]["data"]["_text"];
  let decoded = decode(data);
  responseObject.reviewCaseStr = utf8.decode(decoded);
  let jobMsgs = jsonResponse["reviewCase"]["jobMessages"];
  if (!Array.isArray(jobMsgs)) {
    console.log("Not an Array.. So pushing")
    if (jobMsgs !== undefined)
      responseObject.jobMessages.push(jobMsgs)
  } else {
    responseObject.jobMessages = jobMsgs;
  }
  return responseObject;
}

export async function invokeGenerateDraft(draftString) {
  var myHeaders = new Headers();
  console.log(draftString);
  var fnolKey = getCookie('FNOLKEY');
  myHeaders.append("Authorization", 'Bearer ' + fnolKey);
  myHeaders.append("Content-Type", "application/json");

  var req = encode(utf8.encode(draftString));
  var url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/generateDraft?includeDocumentData=true';
  if(WS_REGION === 'prdssg')
  url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/generateDraft?includeDocumentData=true';
  var raw = JSON.stringify({ "transactionData": req, "batchConfigResId": 690008962, "transactionRange": "1", "transactionDataType": "application/xml" });

  console.log(raw);

  var requestOptions = {
    method: 'POST',
    credentials: 'include',
    headers: myHeaders,
    body: raw,
    redirect: 'follow'
  };

  console.log("sending draft: ");
  console.log(requestOptions);
  return fetch(url, requestOptions)
    .then(response => response.text())
    .then(result => {
      return getData(result);
    }
    )
    .catch(error => {
      console.log('Here: ', error)
      throw new Error('SmartComm invokeGenerateDraft failed: ', error)
    }
    );
}