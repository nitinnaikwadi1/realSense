import dev01resp from '../../../sampleData/dev01_listAllFolderItemsResponse.json';
import jsonResponse from '../../../sampleData/listAllFolderItemsResponse.json';

import { WS_REGION } from '../../../components/constants/GlobalConstants';
import { ALL_EXCEPT, ALL, UNRESTRICTED, FIRST_CLASS_DELIVERY } from '../../../components/constants/SelectParamsConst';



export async function getTemplateLists() {
  console.log(WS_REGION);
  var resp = dev01resp;
  // we are using jsonResponse for INT, PERF, QA and PROD 
  //as per business confirmation
  
  resp = WS_REGION === 'devssg' ? dev01resp : jsonResponse;
  console.log(resp)
  var respTemplatesArr = [];
  var mapLobStrings = {
    PLProperty: "Personal Property",
    CLProperty: "Commercial Property",
    FarmRanch: "Farm Ranch",
    CLAuto: "Commercial Auto",
    PLAuto: "Personal Auto",
    CLAUTO: "Commercial Auto",
    PLAUTO: "Personal Auto",
  };
  var templateFoldersArr = resp["claimsFolder"]["templateFolders"];
  for (var i in templateFoldersArr) {
    var templatesArr = templateFoldersArr[i]["TemplateFolder"];
    for (var j in templatesArr) {
      var eachTemplateDir = templatesArr[j]["items"];
      for (var k in eachTemplateDir) {
        if (eachTemplateDir[k]["tags"] !== null) {
          const KW_PATTERN = '=';
          //check for CLRMV flag to identify whether template to be filtered from list
          const templateFlag = String(eachTemplateDir[k]["tags"].filter(name => name.includes('CLRMV=')));
          if(templateFlag === '' || 
              (templateFlag.slice(templateFlag.indexOf(KW_PATTERN) + 1, templateFlag.length) !== 'Y')){              
            var tags = String(eachTemplateDir[k]["tags"].filter(name => name.includes('KW=')));
            
            var keywords = tags.slice(tags.indexOf(KW_PATTERN) + 1, tags.length).replace(/_/g, ", ");

            var tag_stn = String(eachTemplateDir[k]["tags"].filter(name => name.includes('STN=')));
            var stnList = tag_stn.slice(tag_stn.indexOf(KW_PATTERN) + 1, tag_stn.length).replace(/_/g, ", ");

            var tag_states = String(eachTemplateDir[k]["tags"].filter(name => name.includes('ST=')));
            var statesList = tag_states.slice(tag_states.indexOf(KW_PATTERN) + 1, tag_states.length).replace(/_/g, ", ");

            if (stnList !== '') {
              statesList = ALL_EXCEPT + stnList;
            }

            if (statesList === '') {
              statesList = ALL;
            }

            var tag_lob = String(eachTemplateDir[k]["tags"].filter(name => name.includes('LOB=')));
            var lobList = tag_lob.slice(tag_lob.indexOf(KW_PATTERN) + 1, tag_lob.length).replace(/_/g, ", ");

            if (lobList === '') {
              lobList = ALL;
            }

            if (lobList !== '' && lobList !== 'ALL') {
              lobList = lobList.replace(/PLProperty|CLProperty|FarmRanch|CLAuto|PLAuto|CLAUTO|PLAUTO/gi, function (matched) {
                return mapLobStrings[matched];
              });
            }

            var tag_language = String(eachTemplateDir[k]["tags"].filter(name => name.includes('LN=')));
            var language;
            if (tag_language === '') {
              language = "ENGLISH";
            } else
              language = tag_language.slice(tag_language.indexOf(KW_PATTERN) + 1, tag_language.length);

            var tag_archive = String(eachTemplateDir[k]["tags"].filter(name => name.includes('ARV=')));
            var archiveOnly;
            if (tag_archive === '') {
              archiveOnly = "N";
            } else
              archiveOnly = tag_archive.slice(tag_archive.indexOf(KW_PATTERN) + 1, tag_archive.length);

            //approval level
            var tag_approval = String(eachTemplateDir[k]["tags"].filter(name => name.includes('AL=')));
            var approvalLevel;
            if (tag_approval === '') {
              approvalLevel = "0";
            } else
              approvalLevel = tag_approval.slice(tag_approval.indexOf(KW_PATTERN) + 1, tag_approval.length);

            //doc security
            var tag_docSecurity = String(eachTemplateDir[k]["tags"].filter(name => name.includes('DS=')));
            var docSecurity;
            if (tag_docSecurity === '') {
              docSecurity = UNRESTRICTED;
            } else
              docSecurity = tag_docSecurity.slice(tag_docSecurity.indexOf(KW_PATTERN) + 1, tag_docSecurity.length).toUpperCase();

            //delivery type
            var tag_deliveryType = String(eachTemplateDir[k]["tags"].filter(name => name.includes('DLV=')));
            var deliveryTypeList = tag_deliveryType.slice(tag_deliveryType.indexOf(KW_PATTERN) + 1, tag_deliveryType.length).replace(/_/g, ",");

            if (deliveryTypeList === '') {
              deliveryTypeList = FIRST_CLASS_DELIVERY;
            }

            //override branding 
            var tag_overrideBranding = String(eachTemplateDir[k]["tags"].filter(name => name.includes('OVBR=')));
            var overrideBranding;
            if (tag_overrideBranding === '') {
              overrideBranding = "N";
            } else
              overrideBranding = tag_overrideBranding.slice(tag_overrideBranding.indexOf(KW_PATTERN) + 1, tag_overrideBranding.length);

            //return envelop 
            var tag_returnEnvelop = String(eachTemplateDir[k]["tags"].filter(name => name.includes('BRE=')));
            var returnEnvelop;
            if (tag_returnEnvelop === '') {
              returnEnvelop = "N";
            } else
              returnEnvelop = tag_returnEnvelop.slice(tag_returnEnvelop.indexOf(KW_PATTERN) + 1, tag_returnEnvelop.length);

            var templateCategory = String(eachTemplateDir[k]["tags"].filter(name => name.includes('CAT=')));
            var resourceType = templateCategory.slice(templateCategory.indexOf(KW_PATTERN) + 1, templateCategory.length).replace(/_/g, ", ");
            respTemplatesArr.push({
              resourceName: eachTemplateDir[k]["itemName"],
              description: eachTemplateDir[k]["description"],
              fullPath: templatesArr[j]["fullPath"],
              resourceId: eachTemplateDir[k]["itemId"],
              tags: keywords,
              states: statesList,
              stn: stnList,
              resourceType: resourceType,
              language: language,
              lob: lobList,
              archiveOnly: archiveOnly,
              approvalLevel: approvalLevel,
              docSecurity: docSecurity,
              deliveryTypes: deliveryTypeList,
              overrideBranding: overrideBranding,
              returnEnvelop: returnEnvelop
            });
          }
        }
      }
    }
  }
  return (respTemplatesArr);
}