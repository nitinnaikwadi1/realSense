import { getCookie } from '../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG, WS_PROCESS_ID } from '../../../components/constants/GlobalConstants';
import { CLAIMS_ROOT_FOLDER, FILTER_SHARED_RESOURCE_TEMPLATES, FILTER_ENCLOSURE } from '../../../components/constants/SelectParamsConst';


var requestOptions = null;
export async function int01_getTemplatesJSON() {
  let BASE_URL_PREFIX = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/cms/v7/folders/';
  if (WS_REGION === 'prdssg')
    BASE_URL_PREFIX = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/cms/v7/folders/';
  const BASE_URL_SUFFIX = "/items";
  var myHeaders = new Headers();
  var fnolKey = getCookie('FNOLKEY');
  myHeaders.append("Authorization", 'Bearer ' + fnolKey);
  myHeaders.append("systemName", "SBSS");
  myHeaders.append("processID", WS_PROCESS_ID);
  myHeaders.append("Accept", "application/json");
  requestOptions = {
    method: 'GET',
    credentials: 'include',
    headers: myHeaders
  };
  var int01_JSONObj = [];
  let apiArr = [];

  let int01_rootFolder = {};
  // get the root folder
  const rootFolderId = await fetch(BASE_URL_PREFIX, requestOptions).then(response => response.text())
    .then((json) => {
      var int01TemplateFolderId;
      var rootFolderResponse = JSON.parse(json.slice(9));
      //getting claims folder id from root directory
      rootFolderResponse.forEach(rootFolder => {
        if (rootFolder.name === CLAIMS_ROOT_FOLDER) {
          int01_rootFolder = { "claimsFolder": rootFolder };
          int01TemplateFolderId = rootFolder.id;
        }
      });
      return int01TemplateFolderId;
    }).catch((error) => {
      console.log("int01 root folder API Err::" + error);
      throw new Error("int01 root folder API Failed");
    });

  //refresh int01 templates

  const responseIds = await fetch(BASE_URL_PREFIX + rootFolderId + BASE_URL_SUFFIX, requestOptions).then(response => response.text())
    .then((json) => {
      let int01TemplateFolderIds = [];
      var jsonResponse = JSON.parse(json.slice(9));

      //filter out the shared resource and enclosure template folders
      var filteredTemplatesFolders = [...jsonResponse].filter((eachFolder) => {
        if ((eachFolder.itemName.toLowerCase().trim() !== FILTER_SHARED_RESOURCE_TEMPLATES.toLowerCase().trim()) &&
          (eachFolder.itemName.toLowerCase().trim() !== FILTER_ENCLOSURE.toLowerCase().trim())) {
          return eachFolder;
        } return false;
      });

      let idsAPIArr = [];
      //getting all templates folder ids from root directory
      filteredTemplatesFolders.forEach((templateFolder) => {
        idsAPIArr.push(fetch(BASE_URL_PREFIX + templateFolder.itemId + BASE_URL_SUFFIX, requestOptions));
        console.log(templateFolder.itemName);
      });

      return Promise.all(idsAPIArr)
        .then(values => Promise.all(values.map(value => value.text())))
        .then(async finalVals => {
          finalVals.forEach((element, index) => {
            let ecahElementValues = JSON.parse(element.slice(9));
            //alert(JSON.stringify(ecahElementValues));
            int01TemplateFolderIds.push({
              "id": ecahElementValues[0].itemId,
              "name": filteredTemplatesFolders[index].itemName,
              "level": "2",
              "TemplateFolder": []
            });
          }); return int01TemplateFolderIds;
        });
    }).catch((error) => {
      console.log("int01 Template API Err::" + error);
      throw new Error("int01 Template API Failed");
    });

  //we have template folder ids now using that will fetch templates inside
  for (var templateFolder of responseIds) {
    apiArr.push(fetch(BASE_URL_PREFIX + templateFolder.id + BASE_URL_SUFFIX, requestOptions));
  }
  int01_JSONObj = int01_rootFolder;
  const values = await Promise.all(apiArr);
  const finalVals_1 = await Promise.all(values.map(value => value.text()));
  finalVals_1.forEach((element, index) => {
    let allTemplatesInFolder = JSON.parse(element.slice(9));
    //push templates in the folders json
    var items = {
      "name": "Templates",
      "level": 3,
      "items": allTemplatesInFolder
    };
    responseIds[index]["TemplateFolder"].push(items);
    int01_JSONObj["claimsFolder"].templateFolders = responseIds;
  });
  console.log(int01_JSONObj)
  return int01_JSONObj;
}
