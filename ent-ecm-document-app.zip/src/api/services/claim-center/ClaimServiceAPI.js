import { getClaimContacts } from './claim-service/ClaimContactsGateway'
import { getClaimInfo } from './claim-service/ClaimInfoGateway';
import { getRelatedToInfo } from './claim-service/ClaimRelatedToGateway';
import { retrieveClaimDocuments } from './cc-claimdocument/ClaimGetDocGateways';

import {EMAIL_AS_DELIVERY_TYPE, OTHER_DELIVERY_TYPE} from '../../../components/constants/SelectParamsConst';

var response = {
    status: '',
    recInfo: null,
    senderInfo: null,
    claimInfo: null,
    relatedTo: null,
    deliveryType: null,
}

export async function invokeClaimsAPI(claimNumber, mode) {
    let contactsResp = await getRecipients(claimNumber);
    response.recInfo = contactsResp.recipientsInfo;
    response.senderInfo = contactsResp.senderInfo;
    response.claimInfo = await getStates(claimNumber);
    response.relatedTo = await getRelatedTo(claimNumber, mode);
    response.deliveryType = await getdeliveryType(mode);

    return response;
}

export async function getDocuments(claimNumber, senderId) {
    try {
        const response = await retrieveClaimDocuments(claimNumber, senderId);
        return response
    } catch (error) {
        console.log("ClaimDocuments Error : " + error);
    }
}

async function getRecipients(claimNumber) {
    try {
        const response = await getClaimContacts(claimNumber);
        return response;
    } catch (error) {
        console.log("ClaimContact Service Error : " + error);
    }

}

async function getStates(claimNumber) {
    try {
        const response = await getClaimInfo(claimNumber);
        return response;

    } catch (error) {
        console.log("ClaimInfo Service Error : " + error);
        throw new Error("Failed");
    }
}


async function getRelatedTo(claimNumber, mode) {
    try {
        const response = await getRelatedToInfo(claimNumber, mode);
        return response;

    } catch (error) {
        console.log("ClaimInfo Service Error : " + error);
    }
}

async function getdeliveryType(mode){

    if(mode === 'email'){
        return (EMAIL_AS_DELIVERY_TYPE);
    } else {
        return (OTHER_DELIVERY_TYPE);
    }

}