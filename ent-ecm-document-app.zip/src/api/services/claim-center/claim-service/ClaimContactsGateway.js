import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG, WS_PROCESS_ID } from '../../../../components/constants/GlobalConstants';
import { NONE } from '../../../../components/constants/SelectParamsConst';

async function mapResponseData(responseJson) {
    var contactResponse = {
        senderInfo: '',
        recipientsInfo: '',
    }
    try {
        if (responseJson.Status.code === '200') {
            var recipients = [{ 'id': NONE, 'displayName': NONE, 'selected': true }];
            const contacts = responseJson.claimContacts.filter((item) => {
                if (item.isUserContact === false) {
                    if ((item.displayName !== 'Amfam') && (item.displayName !== ''))
                        return item;
                }
                return false;
            });
            var addInsuredIndex = 1;
            recipients = recipients.concat(contacts.map(contact => {
                let publicID = contact.contactID.split('@');
                let isInsuredParty = false;
                let isDualInsuredPartyType = false;
                

                //identify the insured recipient
                for (var claimRole of contact.claimRoles) {
                    if(claimRole["roleCode"] === 'insured'){
                        isInsuredParty = true;
                        contact.displayName = "Insured 1: "+contact.displayName;
                    }
                }
                if("coveredPartyTypeCode" in contact && contact.coveredPartyTypeCode === "addinsured"){
                    isDualInsuredPartyType = true;
                    addInsuredIndex++;
                    contact.displayName = "Insured "+addInsuredIndex+": "+contact.displayName;
                }
                return { 'id': publicID[1], 'displayName': contact.displayName, 'selected': false, 'isDualInsuredParty':  isDualInsuredPartyType, 'isInsuredParty':isInsuredParty}
            }));

            const senderInfo = responseJson.claimContacts.filter(item => {
                if (item.isUserContact === true && item.proxyUser === false) {
                    if ((item.displayName !== 'Amfam') && (item.displayName !== '') && (item.userId !== 'defaultowner'))
                        return item;
                }
                return false;
            });

            contactResponse.senderInfo = senderInfo;
            contactResponse.recipientsInfo = recipients;
            return contactResponse;
        } else {
            throw new Error('ClaimContacts service failed with code: ' + responseJson.Status.code);
        }
    } catch (error) {
        throw new Error("ClaimContacts error while processing the response: " + error);
    }
}

export async function getClaimContacts(claimNumber) {
    //var fnolKey = await getCommLinkKey();
    var fnolKey = getCookie('FNOLKEY');
    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimContact?claimNumber=' + claimNumber;
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimContact?claimNumber=' + claimNumber
    return fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'systemName': 'SBSS',
            'processID': WS_PROCESS_ID,
        }
    }).then(response => response.json())
        .then((json) => {
            return mapResponseData(json);
        }).catch((error) => {
            console.log("Claimcontacts Error:" + error);
            throw new Error("Claimcontacts Failed");
        }
        );

}
