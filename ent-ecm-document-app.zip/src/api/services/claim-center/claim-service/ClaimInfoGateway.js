import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';

import { WS_REGION, WS_LEG, WS_PROCESS_ID } from '../../../../components/constants/GlobalConstants';
import { LOB, NONE } from '../../../../components/constants/SelectParamsConst'

async function mapResponseData(response, clmNo) {
    var claimInfo = {
        statusCode:'',
        claimNumber: '',
        policyState: '',
        lossState: '',
        lobs: [],
        lobId:'',
        lineOfBusiness:''
    };

    if(response.Status.code === '200'){
        claimInfo.statusCode = response.Status.code;
        claimInfo.claimNumber = clmNo;
        claimInfo.lineOfBusiness = response.claimInfo.lineOfBusiness;

        // as part of [E1PCEOSOC-434] - policy state code attribute can be missing in API
        if("policyStateCode" in response.claimInfo)
            claimInfo.policyState = response.claimInfo.policyStateCode;
        else
            claimInfo.policyState = NONE;
        
        claimInfo.lossState = response.claimInfo.lossLocationAddress.state;
        return mapLOB(claimInfo);    
    } else{
        throw new Error("Service Failed");
    }
}

async function mapLOB(claimInfo) {
    let matchingLOB = null;
    switch (claimInfo.lineOfBusiness) {
        case 'Homeowners Line':
            matchingLOB = 'Personal Property';
            break;
        case 'Commercial Property Line':
            matchingLOB = 'Commercial Property';
            break;
        case 'Farm Ranch Line':
            matchingLOB = 'Farm Ranch';
            break;
        case 'Personal Auto Line':
            matchingLOB = 'Personal Auto';
            break;
        case 'Commercial Auto Line':
            matchingLOB = 'Commercial Auto';
            break;
        default:
            // unknown LOB received    
    }
    LOB.forEach(element => {
        if (element.displayName === matchingLOB) {
            let newLOB = element;
            newLOB.selected = true;
            claimInfo.lobs.push(newLOB);
            claimInfo.lobId = matchingLOB;
        } else {
            claimInfo.lobs.push(element);        }
    });

    return claimInfo;
}

export async function getClaimInfo(claimNumber) {
    //var fnolKey = await getCommLinkKey();
    var fnolKey = getCookie('FNOLKEY');
    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimInfo/' + claimNumber + '?includeExposures=true&includeIncidents=true&detailLevel=detail';
    if (WS_REGION === 'prdssg')
    url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimInfo/' + claimNumber + '?includeExposures=true&includeIncidents=true&detailLevel=detail';
    console.log(url)
    return fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'systemName': 'SBSS',
            'processID': WS_PROCESS_ID,
        }
    }).then(response => response.json())
        .then((json) => {
                console.log(json);
                return mapResponseData(json, claimNumber);
        }).catch((error) => {
            console.log("ClaimInfo Err::" + error);
            throw new Error("ClaimInfo Failed");
        }
        );

}
