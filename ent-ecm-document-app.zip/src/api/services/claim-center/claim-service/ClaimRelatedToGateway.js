import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import XMLParser from "xml-js";

import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';

export function getResponseData(responseXML, mode) {
    if (mode !== 'email') {
        var relatedToEmailMode = [{ 'id': 'None', 'displayName': 'None', 'selected': true }];
        var responseEmailMode = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponseEmailMode = JSON.parse(responseEmailMode);
        var entriesEmailMode = jsonResponseEmailMode["soap12:Envelope"]["soap12:Body"]["fetchRelatedToListResponse"]["return"]["pogo:KeyValuePairList"];

        for (var i in entriesEmailMode.Entry) {
            if (entriesEmailMode.Entry[i]["pogo:Value"]["_text"] !== 'Amfam')
                if (entriesEmailMode.Entry[i]["pogo:TypeOf"]["_text"] === 'Claim') {
                    relatedToEmailMode.push({ 'id': entriesEmailMode.Entry[i]["pogo:Key"]["_text"] + '@' + entriesEmailMode.Entry[i]["pogo:TypeOf"]["_text"], 'displayName': entriesEmailMode.Entry[i]["pogo:TypeOf"]["_text"], 'selected': false });
                } else {
                    relatedToEmailMode.push({ 'id': entriesEmailMode.Entry[i]["pogo:Key"]["_text"] + '@' + entriesEmailMode.Entry[i]["pogo:TypeOf"]["_text"], 'displayName': entriesEmailMode.Entry[i]["pogo:Value"]["_text"], 'selected': false });
                }
        }
        return relatedToEmailMode;
    } else {
        var relatedTo = [];
        var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponse = JSON.parse(response);
        var entries = jsonResponse["soap12:Envelope"]["soap12:Body"]["fetchRelatedToListResponse"]["return"]["pogo:KeyValuePairList"];

        for (var j in entries.Entry) {
            if (entries.Entry[j]["pogo:Value"]["_text"] !== 'Amfam')
                if (entries.Entry[j]["pogo:TypeOf"]["_text"] === 'Claim') {
                    relatedTo.push({ 'id': entries.Entry[j]["pogo:Key"]["_text"] + '@' + entries.Entry[j]["pogo:TypeOf"]["_text"], 'displayName': entries.Entry[j]["pogo:TypeOf"]["_text"], 'selected': true });
                } else {
                    relatedTo.push({ 'id': entries.Entry[j]["pogo:Key"]["_text"] + '@' + entries.Entry[j]["pogo:TypeOf"]["_text"], 'displayName': entries.Entry[j]["pogo:Value"]["_text"], 'selected': false });
                }
        }
        return relatedTo;
    }

}

export async function getRelatedToInfo(claimNo, mode) {
    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/RelatedToList';
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/RelatedToList';
    //var res = await getCommLinkKey();
    var fnolKey = getCookie('FNOLKEY');
    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:rel="http://guidewire.com/cc/ws/com/claimadjuster/typelist/RelatedToListAPI" xmlns:typ="http://example.com/amfam/cc/claimadjuster/typelist"><soap:Body><rel:fetchRelatedToList><rel:request><typ:ClaimNumber>';
    let dataSuffix = '</typ:ClaimNumber></rel:request></rel:fetchRelatedToList></soap:Body></soap:Envelope>';
    let data = dataPrefix + claimNo + dataSuffix;
    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getResponseData(result, mode))
        .catch(error => console.log('error', error));
}