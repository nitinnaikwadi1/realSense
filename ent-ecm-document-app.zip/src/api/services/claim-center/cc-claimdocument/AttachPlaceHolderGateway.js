import XMLParser from "xml-js";

import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';


function getStatus(responseXML) {
    try {
        console.log(responseXML);
        var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponse = JSON.parse(response);
        console.log(jsonResponse);
        var obj = jsonResponse["soap12:Envelope"]["soap12:Body"]["uploadAttachedDocumentPlaceholderResponse"]["return"]["pogo:JSONResponse"]["_text"];
        obj = JSON.parse(obj);
        console.log(obj.messageResponse);
        return obj.messageResponse.status;
    } catch (error) {
        throw new Error('unable to process uploadAttachDocPlaceholder response');
    }

}


export async function uploadAttachedDocumentPlaceholder(docPublicId) {
    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimDocument';
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimDocument';
    var fnolKey = getCookie('FNOLKEY');
    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:api="http://guidewire.com/amfam/cc/claimdocument/api" xmlns:proc="http://guidewire.com/amfam/cc/document/dto/processdocumentrequest" xmlns:aud="http://guidewire.com/cc/ws/gw/webservice/auditInfo"><soap:Body><api:uploadAttachedDocumentPlaceholder><api:processDocRequest><proc:AuditInfo><aud:ConsumerTransactionID>?</aud:ConsumerTransactionID><aud:ProcessID>?</aud:ProcessID><aud:SystemName>SBSS</aud:SystemName><aud:UserID>#UserID</aud:UserID></proc:AuditInfo><proc:JSONRequest>';
    let dataSuffix = '</proc:JSONRequest></api:processDocRequest></api:uploadAttachedDocumentPlaceholder></soap:Body></soap:Envelope>';
    let data = dataPrefix + docPublicId + dataSuffix;
    console.log('about to send ' + data);

    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getStatus(result))
        .catch(error => { throw new Error('uploadAttachDocPlaceholder failed while invoking: ', error) });
}