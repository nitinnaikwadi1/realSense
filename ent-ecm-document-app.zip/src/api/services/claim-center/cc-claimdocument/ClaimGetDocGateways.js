import XMLParser from "xml-js";

import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';


function getClaimDocuments(responseXML) {
    console.log(responseXML);
    var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
    var jsonResponse = JSON.parse(response);
    var payload = jsonResponse["soap12:Envelope"]["soap12:Body"]["retrieveClaimDocumentsResponse"]["return"]["pogo:JSONResponse"]["_text"];
    var obj = JSON.parse(payload).ClaimDocuments;
    return obj;
}


export async function retrieveClaimDocuments(claimNumber, requesterId) {

    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimDocument';
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimDocument';
    var fnolKey = getCookie('FNOLKEY');
    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:api="http://guidewire.com/amfam/cc/claimdocument/api" xmlns:cla="http://guidewire.com/amfam/cc/document/api/claimdocumentrequest" xmlns:aud="http://guidewire.com/cc/ws/gw/webservice/auditInfo"><soap:Header></soap:Header><soap:Body><api:retrieveClaimDocuments><api:claimDocRequest><cla:AuditInfo><aud:ConsumerTransactionID>?</aud:ConsumerTransactionID><aud:ProcessID>?</aud:ProcessID><aud:SystemName>?</aud:SystemName><aud:UserID>#UserID</aud:UserID></cla:AuditInfo>';
    let dataSuffix = '</api:claimDocRequest></api:retrieveClaimDocuments></soap:Body></soap:Envelope>';
    let dataClaimNo = '<cla:ClaimNumber>' + claimNumber + '</cla:ClaimNumber>';
    let dataFilter = '<cla:FilterMimeTypes><cla:Entry>application/pdf</cla:Entry><cla:Entry>image/tiff</cla:Entry><cla:Entry>image/tif</cla:Entry></cla:FilterMimeTypes>'
    let dataRequesterId = '<cla:RequesterId>' + requesterId + '</cla:RequesterId>';

    let data = dataPrefix + dataClaimNo + dataFilter + dataRequesterId + dataSuffix;
    console.log('about to send ' + data);

    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getClaimDocuments(result))
        .catch(error => { throw new Error('GenerateDraftAPI failed while invoking: ', error) });



}