import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import XMLParser from "xml-js";
import { encode } from "base-64";
import utf8 from "utf8";


import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';
import { CDATA_PREFIX, CDATA_SUFFIX } from '../../../../components/constants/SelectParamsConst';


function getStatus(responseXML) {
    try {
        console.log("ProcessDoc Response:" + responseXML);
        var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponse = JSON.parse(response);
        var payload = jsonResponse["soap12:Envelope"]["soap12:Body"]["processDocumentResponse"]["return"]["pogo:JSONResponse"]["_text"];
        var obj = JSON.parse(payload);
        
        if (obj.messageResponse.status === 'Error' && (obj.messageResponse.messages !== undefined 
            && obj.messageResponse.messages.length >0)){
            return obj.messageResponse;
        }

        if (obj.messageResponse.status === 'Success')
            return obj.messageResponse.status;
        else
            throw new Error("ProcessDocGateway failed: " + obj.messageResponse.status);
    } catch (error) {
        throw new Error("ProcessDocGateway Exception: " + error);
    }

}


export async function invokeProcessDocument(claimNumber, reviewCase, docPublicID, deliveryMethod, templateCreator, approver, isFinalized, approvalLevel, action, archiveOnly, reviewComments, draftID, respAttachments, recipientsDataArr, xmlPayload,selectedTemplatesArr) {
    console.log('Inside ProcessDocument:' + templateCreator);
    let attach = []
    let archiveValue;
    let letterType = '';
    // Decision on Approval/Draft and New Template flow and redefining values
    if (docPublicID === undefined) {
        docPublicID = '';
        reviewComments = '';
        action = '';
        respAttachments.forEach(attachment => {
            attach.concat(attachment);
        });
        archiveValue = archiveOnly === 'Y' ? true : false;
        letterType = deliveryMethod === 'EMAIL' ? 'INTERACTIVE_EMAIL' : 'INTERACTIVE_LETTER';
    } else {
        if (isFinalized)
            templateCreator = '';
        deliveryMethod = '';
        draftID = '';
        letterType = '';
        archiveOnly = '';
        approvalLevel = '';
        respAttachments = [];
        archiveValue = '';
        if (action === 'Draft' || action === 'Approval') {
            action = '';
        }
    }


    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimDocument';
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimDocument';
    var fnolKey = getCookie('FNOLKEY');
    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:api="http://guidewire.com/amfam/cc/claimdocument/api" xmlns:proc="http://guidewire.com/amfam/cc/document/dto/processdocumentrequest" xmlns:aud="http://guidewire.com/cc/ws/gw/webservice/auditInfo"><soap:Body><api:processDocument><api:processDocRequest><proc:AuditInfo><aud:ConsumerTransactionID>?</aud:ConsumerTransactionID><aud:ProcessID>?</aud:ProcessID><aud:SystemName>SBSS</aud:SystemName><aud:UserID>#UserID</aud:UserID></proc:AuditInfo><proc:JSONRequest>';
    let dataSuffix = '</proc:JSONRequest></api:processDocRequest></api:processDocument></soap:Body></soap:Envelope>';
    let value = encode(utf8.encode(reviewCase));
    //xmlPayload needs to encoded and passed
    let encodedXmlPayload = encode(utf8.encode(xmlPayload));

    let data = {
        "claimNumber": claimNumber, "xmlpayload": encodedXmlPayload, "draftXML": value, "docPublicID": docPublicID, "deliveryMethod": deliveryMethod,
        "templateCreator": templateCreator, "approver": approver, "finalize": isFinalized, "approvalLevel": approvalLevel, "action": action,
        "archiveOnly": archiveValue, "reviewComments": reviewComments, "letterType": letterType, "draftID": draftID,
        "attachments": respAttachments, "recipients": recipientsDataArr, selectedTemplates : selectedTemplatesArr
    };
    data = dataPrefix + CDATA_PREFIX + JSON.stringify(data) + CDATA_SUFFIX + dataSuffix;
    console.log('about to send ' + data);
    console.log('URL about to send ' + url);

    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getStatus(result))
        .catch(error => { throw new Error('GenerateDraftAPI failed while invoking: ', error) });



}