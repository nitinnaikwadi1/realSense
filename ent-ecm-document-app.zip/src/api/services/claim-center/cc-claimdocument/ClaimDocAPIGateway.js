import XMLParser from "xml-js";


import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';
import { CDATA_PREFIX, CDATA_SUFFIX } from '../../../../components/constants/SelectParamsConst';

function getXMLPayload(responseXML) {
    try {
        console.log(responseXML)
        var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponse = JSON.parse(response);
        var payload = jsonResponse["soap12:Envelope"]["soap12:Body"]["generateDocumentPayloadResponse"]["return"]["pogo:JSONResponse"]["_text"];
        var obj = JSON.parse(payload);
        console.log(obj.messageResponse);
        if (obj.messageResponse.status === 'Success')
            return obj;
        else if (obj.messageResponse.status === 'Error'){
            return obj.messageResponse;
        }    
        else 
            throw new Error("ClaimDocAPI exception: " + obj.messageResponse.status);
    } catch (error) {
        throw new Error('ClaimDocAPI exception while processing response: ' + error);
    }
}

// This policyStateCd is a urgent fix for claimcenter dependent story. Nitin is working for SPA. He will correct the stateCd as required.
export async function getFullPayLoadXML(draftInfo, archiveOnly) {
    console.log(draftInfo);
    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimDocument';
    if (WS_REGION === 'prdssg')
    url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimDocument';
    var fnolKey = getCookie('FNOLKEY');
    let updateSelectedTemplates = [];
    draftInfo.selectedTemplates.forEach((element, index) => {
        let attachments = [];
        element.attachmentIDs.forEach(attachment => {
            attachments = attachments.concat(attachment.DocUID);
        })
        updateSelectedTemplates = updateSelectedTemplates.concat({ "templateID": element.templateID, "templateName": element.templateName, "overrideBrand": element.overrideBrand,"returnEnvelope": element.returnEnvelope, "sequence": index+1, attachmentIDs: attachments });
    });

    let letterType = draftInfo.deliveryType === 'EMAIL' ? 'INTERACTIVE_EMAIL' : 'INTERACTIVE_LETTER';
    draftInfo.selectedTemplates = updateSelectedTemplates;

    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:api="http://guidewire.com/amfam/cc/claimdocument/api" xmlns:doc="http://guidewire.com/amfam/cc/document/dto/documentpayloadrequest" xmlns:aud="http://guidewire.com/cc/ws/gw/webservice/auditInfo"><soap:Body><api:generateDocumentPayload><api:docPayloadRequest><doc:AuditInfo><aud:ConsumerTransactionID>1</aud:ConsumerTransactionID><aud:SystemName>SBSS</aud:SystemName><aud:UserID>#UserID</aud:UserID></doc:AuditInfo><doc:JSONRequest>';
    let dataSuffix = '</doc:JSONRequest></api:docPayloadRequest></api:generateDocumentPayload></soap:Body></soap:Envelope>';
    let data = {
        "claimNumber": draftInfo.claimNumber, "senderID": draftInfo.senderExternalID, "recipientID": draftInfo.recipientID, 
        "carbonCopyIDs": draftInfo.carbonCopyID, "blindCarbonCopyIDs": draftInfo.bccID, "lob": draftInfo.lob, 
        "relatedToID": draftInfo.relatedToID, "relatedToType": draftInfo.relatedToType, "letterType": letterType,
        "deliveryType": draftInfo.deliveryType, "language": draftInfo.language, "documentSecurity": draftInfo.documentSecurity,
        "stateCD": draftInfo.otherStateCD.trim(), "selectedTemplates": draftInfo.selectedTemplates, "archiveOnly": archiveOnly, "additionalInsuredID": draftInfo.dualInsuredPartyId
    };

    //adding <!CDATA - wrapper to json object to handle special char present if any
    
    data = dataPrefix + CDATA_PREFIX + JSON.stringify(data) + CDATA_SUFFIX + dataSuffix;
    console.log('about to send ' + data);

    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getXMLPayload(result))
        .catch(error => { throw new Error('GenerateDraftAPI failed while invoking: ', error) });



}