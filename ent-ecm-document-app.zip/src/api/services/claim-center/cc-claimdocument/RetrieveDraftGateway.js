import XMLParser from "xml-js";
import utf8 from "utf8";
import { decode } from "base-64";

import { getCookie } from '../../../../components/doc-mgmt-app/sso/SingleSignOn';
import { WS_REGION, WS_LEG } from '../../../../components/constants/GlobalConstants';


function getEncryptedXML(responseXML) {
    try {
        var response = XMLParser.xml2json(responseXML, { compact: true, spaces: 2 });
        var jsonResponse = JSON.parse(response);
        var payload = jsonResponse["soap12:Envelope"]["soap12:Body"]["retrieveDocumentResponse"]["return"]["pogo:JSONResponse"]["_text"];
        var obj = JSON.parse(payload).DocumentDetail.DraftXML;
        let decoded = decode(obj);
        return utf8.decode(decoded);
    } catch (error) {
        throw new Error('unable to process retrieveDocument response');
    }

}


export async function retrieveDraft(docPublicId) {

    let url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/' + WS_LEG + '/ClaimDocument';
    if (WS_REGION === 'prdssg')
        url = 'https://' + WS_REGION + '.amfam.com/claimecmdocument/v1/ClaimDocument';
    var fnolKey = getCookie('FNOLKEY');
    let dataPrefix = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soap1="http://guidewire.com/ws/soapheaders" xmlns:api="http://guidewire.com/amfam/cc/claimdocument/api" xmlns:doc="http://guidewire.com/amfam/cc/document/api/documentdetailrequest" xmlns:aud="http://guidewire.com/cc/ws/gw/webservice/auditInfo"><soap:Header></soap:Header><soap:Body><api:retrieveDocument><api:docDetailRequest><doc:AuditInfo><aud:ConsumerTransactionID>?</aud:ConsumerTransactionID><aud:ProcessID>?</aud:ProcessID><aud:SystemName>?</aud:SystemName><aud:UserID>#UserID</aud:UserID></doc:AuditInfo><doc:DocPublicID>';
    let dataSuffix = '</doc:DocPublicID></api:docDetailRequest></api:retrieveDocument></soap:Body></soap:Envelope>';
    let data = dataPrefix + docPublicId + dataSuffix;
    console.log('about to send ' + data);

    var requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Authorization': 'Bearer ' + fnolKey,
            'Content-Type': 'application/json',
        },
        body: data,
        redirect: 'follow'
    };

    return fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => getEncryptedXML(result))
        .catch(error => { throw new Error('RetrieveDraft failed while invoking: ', error) });



}