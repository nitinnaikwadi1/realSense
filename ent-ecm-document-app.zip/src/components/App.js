import React from "react";
import LayoutPanel from './doc-mgmt-app/LayoutPanel';
import AlertModel from './doc-mgmt-app/modals/AlertModel';
import RetrieveModal from './doc-mgmt-app/modals/RetrieveModal';
import ApprovalModal from './doc-mgmt-app/modals/ApprovalModal';

import { invokeClaimsAPI } from '../api/services/claim-center/ClaimServiceAPI';
import { retrieveDraft } from '../api/services/claim-center/cc-claimdocument/RetrieveDraftGateway';

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      data: '',
      recipients: [],
      isLaunchSPA: null,
      claimInfo: '',
      relatedTo: '',
      claimDetails: '',
      isException: false,
      documentList: '',
      isDraftString: false,
      draftString: '',
      action: null,
      senderInfo: [],
      deliveryType:[],
    }
    this.updateException = this.updateException.bind(this);
  }

  updateException() {
    this.setState({ isException: true });
  }

  render() {
    console.log("ExceptionIS:" + this.state.action);
    if (!this.state.isException) {
      if (this.state.isLaunchSPA === true)
        return (<LayoutPanel isLoading={this.state.isLoading} senderInfo={this.state.senderInfo} headerData={this.state.data} recipients={this.state.recipients} claimInfo={this.state.claimInfo} relatedTo={this.state.relatedTo} documentList={this.state.documentList} isException={this.updateException} deliveryType={this.state.deliveryType} jsonData={this.props.jsonData}/>)
      else if (this.state.isLaunchSPA === false) {
        if (this.state.action === null) { // This null should be replaced with action Draft after CC is ready
          return <RetrieveModal draftString={this.state.draftString} updateException = {this.updateException} docPublicID={this.props.jsonData.publicID} claimNumber={this.props.jsonData.claimNumber}/>
        } else if (this.state.action === 'Approval') {
          console.log("inside approval");
          return <ApprovalModal claimNumber={this.props.jsonData.claimNumber} draftString={this.state.draftString} action={this.state.action} docPublicID={this.props.jsonData.publicID} approverId={this.props.jsonData.userID} updateException = {this.updateException}/>
        } else if (this.state.action === 'Draft') {
          return <RetrieveModal draftString={this.state.draftString} updateException = {this.updateException} action={this.state.action} docPublicID={this.props.jsonData.publicID} senderID={this.props.jsonData.userID} claimNumber={this.props.jsonData.claimNumber}/>;
        }
      }
      else {
        return (<LayoutPanel isLoading={this.state.isLoading} headerData={this.state.data} recipients={this.state.recipients} claimInfo={this.state.claimInfo} relatedTo={this.state.relatedTo} documentList={this.state.documentList} isException={this.updateException} />)
      }
    } else {
      return (<div> <AlertModel show='true' /> </div>);
    }
  }

  // The cleanup will happen in next release..
  async componentDidMount() {
    try {
      const jsonData = this.props.jsonData;
      let publicID = jsonData.publicID;
      // This logic need to be revisted after the action URL param is ready in claimcenter.
      if (publicID === 'null') {
        let serviceResponse = await invokeClaimsAPI(jsonData.claimNumber, jsonData.mode);
        if (serviceResponse.recInfo !== null && serviceResponse.claimInfo !== null && serviceResponse.relatedTo !== null) {
          this.setState({ data: jsonData, senderInfo: serviceResponse.senderInfo, recipients: serviceResponse.recInfo, isLoading: false, claimInfo: serviceResponse.claimInfo, relatedTo: serviceResponse.relatedTo, documentList: serviceResponse.documentList, isLaunchSPA: true, deliveryType: serviceResponse.deliveryType });
        }
        else
          this.setState({ data: jsonData });
      } else if (publicID !== 'null' && publicID.startsWith('cc:')) {
        try {
          let draftString = await retrieveDraftString(publicID);
          console.log("String: " + draftString);
          if (jsonData.action === null || jsonData.action === undefined)
            this.setState({ isLaunchSPA: false, draftString: draftString });
          else if (jsonData.action === 'Approval')
            this.setState({ isLaunchSPA: false, draftString: draftString, action: 'Approval' });
          else if (jsonData.action === 'Draft')
            this.setState({ isLaunchSPA: false, draftString: draftString, action: 'Draft' });
        } catch (error) {
          console.error("Failed while retrieving draft: " + error);
          this.updateException();
        }
      } else {
        alert("Incorrect URL!!! Please close and try again to launch from ClaimCenter");
      }
    } catch (error) {
      console.error("Failed while processing: " + error);
      this.updateException();
    }
  }
}

async function retrieveDraftString(publicID) {
  try {
    let draftString = await retrieveDraft(publicID);
    return draftString;
  } catch (error) {
    console.error("Failed while retrieving draft: " + error);
    this.updateException();
  }

}

export default App;