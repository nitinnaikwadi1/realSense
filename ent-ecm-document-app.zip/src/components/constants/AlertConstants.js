// Error message to be displayed when template is not selected
export const NO_TEMPLATES_HEADER = 'There are no templates selected.';
export const NO_TEMPLATES_BODY = 'Please select template before you select attachment.';

//Error message to be displayed when #REQUIRED is not fixed in Draft Editor content.

export const REQUIRED_HEADER = 'Invalid fields in Draft content';
export const REQUIRED_BODY = 'Please update the required or invalid fields in the document.\n (NOTE: Value of #REQUIRED is not allowed.)';

export const SMART_COMM_CHOICE_NOT_SELECT_ERROR = '[ERROR] You must select a choice in order to preview.';
export const SMART_COMM_CHOICE_REQUIRED_HEADER = 'Choice list not selected';
export const SMART_COMM_CHOICE_REQUIRED_BODY = 'You must make a selection in any mandatory choice list before creating your correspondence.';

export const CHOICELIST_REQUIRED_BOTH_BODY = 'You must complete the #REQUIRED fields and make a selection in any mandatory choice lists before creating your correspondence.';


// Error message to be displayed when documents are missing
export const NO_DOCUMENTS_HEADER = 'There are no PDF or TIFF documents on this claim.';
export const NO_DOCUMENTS_BODY = 'Please go to ClaimCenter and upload PDF or TIFF documents to attach them to this correspondence.';

// Error message to be displayed when no documents are selected
export const NO_DOCUMENTS_SELECTED_HEADER = 'No Documents Selected.';
export const NO_DOCUMENTS_SELECTED_BODY = 'Select at least 1 document to proceed.';

// Error message to be displayed when claimcenter returns error.
export const ERROR_DOCUMENTS_SELECTED_HEADER = 'Unable to add selected document.';
export const ERROR_DOCUMENTS_SELECTED_BODY = 'System error occured while adding the selection to attachment. Please try again. If problem persist, please contact help desk';


// Error message to be displayed when max documents selected exceeded
export const MAX_DOCUMENTS_SELECTED_HEADER = 'Max Documents Selected.';
export const MAX_DOCUMENTS_SELECTED_BODY = 'Maximum attachments per template cannot exceed 5.';

// Saved Draft alert in the blank page

export const SAVED_COMPLETED = 'Draft created/saved successfully. Please close the browser.';
export const SAVED_DISCARDED = 'Draft has been discarded. Please close the browser.';

// Approval/Rejection alert in the blank page

export const APPROVED_MSG = 'Draft has been approved. Please close the browser.';
export const REJECTED_MSG = 'Draft has been rejected. Please close the browser.';

// Completion Draft alert in the main SPA page.

export const COMPLETION_ALERT_MSG = '[Document Name] has been successfully generated and sent to [Recipient].';
export const COMPLETE_CLOSE_MSG = 'Please create another correspondence or close the browser.';
export const SAVED_ALERT_MSG = 'Draft saved successfully. Please continue generating documents for this claim or close the browser.';

// Error Banner for templates with validation errors.
export const TEMPLATE_VALIDATION_HEADER = 'Document Not Generated Successfully';
export const TEMPLATE_VALIDATION_BODY = 'There was an error producing this template. Please select an exposure in the Related To drop down and/or complete any missing information in ClaimCenter and try your request again. If the problem persists, please contact the Help Desk.';

export const ERROR="Error";

// CC Reset alert message
export const CC_RESET_HEADER = 'Carbon Copies cannot be used with the Archive Only Delivery Type.';
export const CC_RESET_BODY = 'Your CC Selection has been reset. Please choose a different Delivery Type to send a Carbon Copy.';

// CC_BCC_MAX LIMIT alert message

export const REC_MAX_LIMIT_HEADER = 'Carbon Copy or Blind Carbon Copy limited exceeded';
export const REC_MAX_LIMIT_BODY = 'Your selection of Carbon Copy or Blind Carbon Copy recipients cannot exceed 10 recipients.';


// Sender Email not present
export const SENDER_EMAIL_MISSING_HEADER="The sender is not complete.";
