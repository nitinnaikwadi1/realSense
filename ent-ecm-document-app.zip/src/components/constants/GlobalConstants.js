import config from './../../sso-env.json';

export var WS_REGION = '';
export var WS_LEG = '';
export var WS_PROCESS_ID = '';
export var SC_SSO = '';
export var SC_URL = '';

// PERF And QA values are not setup so we refering to INT value. This will be changed after URL is ready.

export function updateEnvValues(envValues) {
    if (envValues !== undefined) {
        let region = envValues.substring(0, 3);
        if (region !== 'prd') {
            let leg = envValues.substring(3, 5);
            WS_LEG = leg === '99' ? '' : leg;
            WS_PROCESS_ID = 'domsrvt';
            SC_URL = 'na10-sb';
            if (region === 'dev') // This If block need to changed after perf and QA is ready in Smartcomm
                SC_SSO = config.dev.url;
            else if (region === 'int') {
                if (leg === '01')
                    SC_SSO = config.int_01.url;
                if (leg === '02')
                    SC_SSO = config.int_02.url;
                if (leg === '03')
                    SC_SSO = config.int_03.url;
                else
                    SC_SSO = config.int.url;

            } else
                SC_SSO = config.int.url;
        } else {
            SC_URL = 'na11';
            SC_SSO = config.prod.url;
            WS_PROCESS_ID = 'domsrvp';
        }

        WS_REGION = region.toLowerCase() + 'ssg';
    }
}