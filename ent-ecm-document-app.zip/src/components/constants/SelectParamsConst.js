export const CATEGORIES = [
    { 'id': 'None', 'displayName': '-Select-', 'selected': true },
    { 'id': 'ALE', 'displayName': 'ALE', 'selected': false },
    { 'id': 'Appraisal', 'displayName': 'Appraisal', 'selected': false },
    { 'id': 'Authorization', 'displayName': 'Authorization', 'selected': false },
    { 'id': 'CCCC', 'displayName': 'CCCC', 'selected': false },
    { 'id': 'ESO', 'displayName': 'ESO', 'selected': false },
    { 'id': 'Injury', 'displayName': 'Injury', 'selected': false },
    { 'id': 'Investigative', 'displayName': 'Investigative', 'selected': false },
    { 'id': 'MedPay', 'displayName': 'Med Pay', 'selected': false },
    { 'id': 'Medicare', 'displayName': 'Medicare', 'selected': false },
    { 'id': 'PIP', 'displayName': 'PIP', 'selected': false },
    { 'id': 'PersonalProperty', 'displayName': 'Personal Property', 'selected': false },
    { 'id': 'ProofOfLoss', 'displayName': 'Proof of Loss', 'selected': false },
    { 'id': 'Reinspect', 'displayName': 'Reinspect', 'selected': false },
    { 'id': 'Status', 'displayName': 'Status', 'selected': false }
];

export const OTHER_DELIVERY_TYPE = [
    { 'id': 'FIRST CLASS', 'displayName': 'First Class USPS Mail', 'selected': true },
    { 'id': 'EMAIL', 'displayName': 'Email', 'selected': false },
    { 'id': 'OVERNIGHT', 'displayName': 'Overnight', 'selected': false },
    { 'id': 'ARCHIVE ONLY', 'displayName': 'Archive Only', 'selected': false },
    { 'id': 'CERTIFICATE', 'displayName': 'Proof of Mail', 'selected': false },
    { 'id': 'CERTIFIED_W_SIGNATURE', 'displayName': 'Certified with Signature', 'selected': false }
];

export const EMAIL_AS_DELIVERY_TYPE = [
    { 'id': 'FIRST CLASS', 'displayName': 'First Class USPS Mail', 'selected': false },
    { 'id': 'EMAIL', 'displayName': 'Email', 'selected': true },
    { 'id': 'OVERNIGHT', 'displayName': 'Overnight', 'selected': false },
    { 'id': 'ARCHIVE ONLY', 'displayName': 'Archive Only', 'selected': false },
    { 'id': 'CERTIFICATE', 'displayName': 'Proof of Mail', 'selected': false },
    { 'id': 'CERTIFIED_W_SIGNATURE', 'displayName': 'Certified with Signature', 'selected': false }
];

export const LOB = [
    { 'id': 'ALL', 'displayName': 'All Lines of Business', 'selected': false },
    { 'id': 'CLAuto', 'displayName': 'Commercial Auto', 'selected': false },
    { 'id': 'CLProperty', 'displayName': 'Commercial Property', 'selected': false },
    { 'id': 'FarmRanch', 'displayName': 'Farm Ranch', 'selected': false },
    { 'id': 'PLAuto', 'displayName': 'Personal Auto', 'selected': false },
    { 'id': 'PLProperty', 'displayName': 'Personal Property', 'selected': false }
];

export const SECURITY_TYPE = [
    { 'id': 'UNRESTRICTED', 'displayName': 'Unrestricted', 'selected': true },
    { 'id': 'SENSITIVE', 'displayName': 'Sensitive', 'selected': false },
];

export const LANGUAGES = [
    { 'id': 'ENGLISH', 'displayName': 'English', 'selected': true },
    { 'id': 'SPANISH', 'displayName': 'Spanish', 'selected': false }
];

export const STATES = [
 { 'id': ' AL', 'displayName': 'Alabama', 'selected': false },
 { 'id': ' AK', 'displayName': 'Alaska', 'selected': false },
 { 'id': ' AS', 'displayName': 'American Samoa', 'selected': false },
 { 'id': ' AZ', 'displayName': 'Arizona', 'selected': false },
 { 'id': ' AR', 'displayName': 'Arkansas', 'selected': false },
 { 'id': ' CA', 'displayName': 'California', 'selected': false },
 { 'id': ' CO', 'displayName': 'Colorado', 'selected': false },
 { 'id': ' CT', 'displayName': 'Connecticut', 'selected': false },
 { 'id': ' DE', 'displayName': 'Delaware', 'selected': false },
 { 'id': ' DC', 'displayName': 'District of Columbia', 'selected': false },
 { 'id': ' FL', 'displayName': 'Florida', 'selected': false },
 { 'id': ' GA', 'displayName': 'Georgia', 'selected': false },
 { 'id': ' GU', 'displayName': 'Guam', 'selected': false },
 { 'id': ' HI', 'displayName': 'Hawaii', 'selected': false },
 { 'id': ' ID', 'displayName': 'Idaho', 'selected': false },
 { 'id': ' IL', 'displayName': 'Illinois', 'selected': false },
 { 'id': ' IN', 'displayName': 'Indiana', 'selected': false },
 { 'id': ' IA', 'displayName': 'Iowa', 'selected': false },
 { 'id': ' KS', 'displayName': 'Kansas', 'selected': false },
 { 'id': ' KY', 'displayName': 'Kentucky', 'selected': false },
 { 'id': ' LA', 'displayName': 'Louisiana', 'selected': false },
 { 'id': ' ME', 'displayName': 'Maine', 'selected': false },
 { 'id': ' MD', 'displayName': 'Maryland', 'selected': false },
 { 'id': ' MA', 'displayName': 'Massachusetts', 'selected': false },
 { 'id': ' MI', 'displayName': 'Michigan', 'selected': false },
 { 'id': ' MN', 'displayName': 'Minnesota', 'selected': false },
 { 'id': ' MO', 'displayName': 'Mississippi', 'selected': false },
 { 'id': ' MS', 'displayName': 'Missouri', 'selected': false },
 { 'id': ' MT', 'displayName': 'Montana', 'selected': false },
 { 'id': ' NE', 'displayName': 'Nebraska', 'selected': false },
 { 'id': ' NV', 'displayName': 'Nevada', 'selected': false },
 { 'id': ' NH', 'displayName': 'New Hampshire', 'selected': false },
 { 'id': ' NJ', 'displayName': 'New Jersey', 'selected': false },
 { 'id': ' NM', 'displayName': 'New Mexico', 'selected': false },
 { 'id': ' NY', 'displayName': 'New York', 'selected': false },
 { 'id': ' NC', 'displayName': 'North Carolina', 'selected': false },
 { 'id': ' ND', 'displayName': 'North Dakota', 'selected': false },
 { 'id': ' MP', 'displayName': 'Northern Mariana Islands', 'selected': false },
 { 'id': ' OH', 'displayName': 'Ohio', 'selected': false },
 { 'id': ' OK', 'displayName': 'Oklahoma', 'selected': false },
 { 'id': ' OR', 'displayName': 'Oregon', 'selected': false },
 { 'id': ' PA', 'displayName': 'Pennsylvania', 'selected': false },
 { 'id': ' PR', 'displayName': 'Puerto Rico', 'selected': false },
 { 'id': ' RI', 'displayName': 'Rhode Island', 'selected': false },
 { 'id': ' SC', 'displayName': 'South Carolina', 'selected': false },
 { 'id': ' SD', 'displayName': 'South Dakota', 'selected': false },
 { 'id': ' TN', 'displayName': 'Tennessee', 'selected': false },
 { 'id': ' TX', 'displayName': 'Texas', 'selected': false },
 { 'id': ' UT', 'displayName': 'Utah', 'selected': false },
 { 'id': ' VT', 'displayName': 'Vermont', 'selected': false },
 { 'id': ' VI', 'displayName': 'Virgin Islands', 'selected': false },
 { 'id': ' VA', 'displayName': 'Virginia', 'selected': false },
 { 'id': ' WA', 'displayName': 'Washington', 'selected': false },
 { 'id': ' WV', 'displayName': 'West Virginia', 'selected': false },
 { 'id': ' WI', 'displayName': 'Wisconsin', 'selected': false },
 { 'id': ' WY', 'displayName': 'Wyoming', 'selected': false }
];

export const ALL_EXCEPT = "All Except ";
export const ALL = "ALL";
export const EMAIL = "EMAIL";
export const NONE='None';
export const SENSITIVE = "SENSITIVE";
export const UNRESTRICTED = "UNRESTRICTED";
export const FIRST_CLASS_DELIVERY = "FSTCL";
export const CERTIFIED_DELIVERY = "CERT";
export const CERTIFICATE_DELIVERY = 'POM';
export const OVERNIGHT_DELIVERY ='OVN';
export const CERTIFIED_WITH_SIGN_DELIVERY ='CERT_WSIG';
export const CDATA_PREFIX = "<![CDATA[";
export const CDATA_SUFFIX = "]]>";
export const UNV_TEMPLATE_STR = "UNV";
export const ARCHIVE_ONLY = "ARCHIVE ONLY";
export const CC_BCC_MAX_LIMIT = 10;
export const DEFAULT_EMAIL_TEMPLATE="EMAIL0045 FREE FORM";


export const CLAIMS_ROOT_FOLDER="AmFam Enterprise Claims";
export const FILTER_SHARED_RESOURCE_TEMPLATES="AF Ent Claims Shared Resources";
export const FILTER_ENCLOSURE="AF Ent Claims Enclosure";
export const AND = " and ";
export const COLON = ":";
export const YES = "YES";
export const NO = "NO";