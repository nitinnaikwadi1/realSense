import React from 'react';
import AddDocumentModal from './modals/AddDocumentModal';
import { getTemplateLists } from '../../api/services/smart-comm/SmartCommGateway';
import { getDocuments } from '../../api/services/claim-center/ClaimServiceAPI';
import TemplatesDialogModel from './modals/TemplatesDialogModel';
import { NO_DOCUMENTS_HEADER, NO_DOCUMENTS_BODY } from '../constants/AlertConstants';
import { DEFAULT_EMAIL_TEMPLATE } from '../constants/SelectParamsConst';

class SelectionTemplate extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isChanged: false,
            selectTemplateList: null,
            chosenTemplateList: [],
            minifiedTemplatesList: [],
            orginalTemplateList: null,
            displayModal: false,
            attachmentTempId: '',
            attachmentSelected: [],
            displayAlert: false,
            selectAsc: true,
            chosenAsc: true,
            displayAttachmentAlertModal: false
        }
        this.hideModal = this.hideModal.bind(this);
        this.updateAttachments = this.updateAttachments.bind(this);
        this.selectSorting = this.selectSorting.bind(this);
        this.chosenSorting = this.chosenSorting.bind(this);
        this.addAttachmentAlertModal = this.addAttachmentAlertModal.bind(this);
        this.hideAttachmentAlertModal = this.hideAttachmentAlertModal.bind(this);
        this.addDocumentsModal = this.addDocumentsModal.bind(this);

    }

    addAttachmentAlertModal() {
        this.setState({ displayAttachmentAlertModal: true });
    }
    hideAttachmentAlertModal = () => {
        this.setState({ displayAttachmentAlertModal: false });
    }

    hideModal = () => {
        this.setState({ displayModal: false });
    }

    selectSorting() {
        this.setState({ selectAsc: !this.state.selectAsc });
    }

    chosenSorting() {
        this.setState({ chosenAsc: !this.state.chosenAsc });
    }

    updateAttachments(templateId, attachmentList) {
        console.log(this.state.minifiedTemplatesList);
        let index = this.state.minifiedTemplatesList.map(t => {
            return t.templateID;
        }).indexOf(templateId);
        console.log("Found Index: " + index);
        let updatedList = this.state.minifiedTemplatesList;
        updatedList[index].attachmentIDs = attachmentList;
        console.log(updatedList);
        this.setState({ minifiedTemplatesList: updatedList, attachmentSelected: attachmentList });
        this.props.handleChange({ id: this.props.id, value: updatedList });

    }

    async addDocumentsModal(template) {
        //clear out any popup validation if present
        this.props.clearValidationAlerts();
        //get the documents count to render model
        let response = await getDocuments(this.props.claimNumber, this.props.senderId);
        if (response === undefined || response.length === 0) {
            this.addAttachmentAlertModal();
        } else {
            this.setState({ displayModal: true, attachmentTempId: template.resourceId });
        }
        console.log(template);
    }

    addSelection(template) {
        var canAdd = true; // Conditional check for template selection threshold...
        if (this.props.threshold !== undefined) {
            if (this.state.chosenTemplateList.length < this.props.threshold) {
                this.setState({ displayAlert: false });

            } else {
                canAdd = false;
                this.setState({ displayAlert: true });
            }
        } else {
        }

        if (canAdd) {
            //check for override branding flag
            var isOverrideBrand = false;
            if (template.overrideBranding === 'Y') {
                isOverrideBrand = true;
            }

            //check for returnEnvelop flag
            var isReturnEnvelop = false;
            if (template.returnEnvelop === 'Y') {
                isReturnEnvelop = true;
            }

            var selectedTemplate = {
                "templateID": template.resourceId, "templateName": template.resourceName,
                "overrideBrand": isOverrideBrand, "returnEnvelope": isReturnEnvelop, "attachmentIDs": []
            };
            var selectedTemplates = this.state.minifiedTemplatesList.concat(selectedTemplate);

            //check if resourceId is already present in selection list
            var isTemplateAlreadySelected = false;
            this.state.chosenTemplateList.some(function (item) {
                if (item.resourceId === template.resourceId) {
                    isTemplateAlreadySelected = true;
                }
                return false;
            });
            var newChosenData = [];
            if (!isTemplateAlreadySelected) {
                newChosenData = this.state.chosenTemplateList.concat(template);
            } else
                newChosenData = this.state.chosenTemplateList;


            let index = this.state.selectTemplateList.map(x => {
                return x.resourceId;
            }).indexOf(template.resourceId);
            console.log("Index: " + index);
            var newSelectData = this.state.selectTemplateList;
            newSelectData.splice(index, 1);
            this.setState({ chosenTemplateList: newChosenData, selectTemplateList: newSelectData, minifiedTemplatesList: selectedTemplates })
            //sending only required attributes for draft editor api

            this.props.handleChange({ id: this.props.id, value: selectedTemplates });

            if (newChosenData.length !== 0) {
                this.props.updateArchiveOnly({ id: 'archiveOnly', value: newChosenData[0]['archiveOnly'] });
                this.props.updateApprovalLevel({ id: 'approvalLevel', value: newChosenData[0]['approvalLevel'] });
                this.props.setDocumentSecurity({ id: 'securityId', value: newChosenData[0]['docSecurity'] });
            }
        }
    }

    removeSelection(template) {
        var newSelectData = this.state.selectTemplateList.concat(template);
        let index = this.state.chosenTemplateList.map(x => {
            return x.resourceId;
        }).indexOf(template.resourceId);
        console.log("Index: " + index);
        var newChosenData = this.state.chosenTemplateList;
        newChosenData.splice(index, 1)
        var selectedTemplates = this.state.minifiedTemplatesList;
        selectedTemplates.splice(index, 1);
        this.setState({ selectTemplateList: newSelectData, chosenTemplateList: newChosenData, minifiedTemplatesList: selectedTemplates, attachmentTempId: '', attachmentSelected: [], displayAlert: false })
        this.props.handleChange({ id: this.props.id, value: selectedTemplates });

        if (newChosenData.length !== 0) {
            this.props.updateArchiveOnly({ id: 'archiveOnly', value: newChosenData[0]['archiveOnly'] });
            this.props.updateApprovalLevel({ id: 'approvalLevel', value: newChosenData[0]['approvalLevel'] });
            this.props.setDocumentSecurity({ id: 'securityId', value: newChosenData[0]['docSecurity'] });
        }
    }


    renderTemplateData(filteredTemplatesList) {
        //filter out the templates already present in chosentemplates list
        var chosenTemplatesArr = this.state.chosenTemplateList;
        var chosenResourceIdArr = [];
        if (chosenTemplatesArr.length >= 1) {
            for (var template of chosenTemplatesArr) {
                chosenResourceIdArr.push(template.resourceId);
            }
            filteredTemplatesList = [...filteredTemplatesList].filter((item) => {
                if (!chosenResourceIdArr.includes(item.resourceId)) {
                    return item;
                }
                return false;
            });
        }
        this.setState({ selectTemplateList: filteredTemplatesList });
    }

    setDefaultForEmailDelivery(){
        // EMAIL0045 is default set for Delivery Type - Email
        //get template from templates list and set
        const defaultEmailTemplate = this.state.selectTemplateList.find( 
            ({ resourceName }) => resourceName === DEFAULT_EMAIL_TEMPLATE );
        if(defaultEmailTemplate !== undefined){
            this.addSelection(defaultEmailTemplate);
        }
    }


    renderChosenData() {
        let sortedList = this.doSorting(this.state.chosenTemplateList, this.state.chosenAsc);
        return sortedList != null ? sortedList.map((template, index) => {
            let attachmentIds = '';
            let indexM = this.state.minifiedTemplatesList.map(element => { return element.templateID }).indexOf(template.resourceId);
            if (indexM !== -1) attachmentIds = this.state.minifiedTemplatesList[index].attachmentIDs;
            return (
                <tr key={index}>
                    <td data-label="remove" className='remove'>
                        <div className="content">
                            <a href='# ' className='icon-delete templateSelect' onClick={this.removeSelection.bind(this, template)}> </a>
                        </div>
                    </td>
                    <td data-label="c-templateName" className='c-templateName'>
                        <div className="content">
                            {template.resourceName}
                        </div>
                    </td>
                    <td data-label="attachmentNames" className='attachments attachmentSelect'>
                        <div className="content">
                            {attachmentIds !== '' ? attachmentIds.map((attachment) => (<div>{attachment.Name}</div>)) : ''}
                        </div>
                        <div className="content">
                            <a href='# ' onClick={this.addDocumentsModal.bind(this, template)}>{attachmentIds.length > 0 ? 'Add/Remove Attachment' : 'Add Attachment'}</a>
                        </div>
                    </td>
                </tr>)
        }) : '';

    }

    doSorting(arrayList, isAscending) {
        if (isAscending) {
            if (arrayList !== null) {
                arrayList.sort(function (a, b) {
                    var textA = a.resourceName.toUpperCase();
                    var textB = b.resourceName.toUpperCase();
                    return textA.localeCompare(textB);
                });
            }
        } else {
            if (arrayList !== null) {
                arrayList.sort(function (a, b) {
                    var textA = a.resourceName.toUpperCase();
                    var textB = b.resourceName.toUpperCase();
                    return textB.localeCompare(textA);
                });
            }
        }
        return arrayList;
    }
    renderTableData() {
        let sortedList = this.doSorting(this.state.selectTemplateList, this.state.selectAsc);
        return sortedList ? sortedList.map((template, index) => {
            return (
                <tr key={index} data-label={index}>
                    <td data-label="select" className='select'>
                        <div className="content" id={template.resourceId}>
                            <a href='# ' className='icon-plus-thick templateSelect' onClick={this.addSelection.bind(this, template)}> </a>
                        </div>
                    </td>
                    <td data-label="templateName" className='templateName'>
                        <div className="content">
                            {template.resourceName}
                        </div>
                    </td>
                    <td data-label="keywords" className='keyword templateKeywordSelect'>
                        <div className="content">
                            {template.tags}
                        </div>
                    </td>
                    <td data-label="category" className='templateCategory templateCatgorySelect'>
                        <div className="content">
                            {template.resourceType}
                        </div>
                    </td>
                    <td data-label="lob" className='lineOfBusiness lobSelect'>
                        <div className="content">
                            {template.lob}
                        </div>
                    </td>
                    <td data-label="States" className='state templateStateSelect'>
                        <div className="content">
                            {template.states}
                        </div>
                    </td>

                </tr>)
        }) : '';
    }

    render() {
        return (
            <div>
                <div id='tSubHeading1' className="heading-section">Select&nbsp;Templates</div>
                <div className='tBorder1' />
                <table className="stripe fill tableSelect hideScroll">
                    <thead>
                        <tr>
                            <th className='select'>Select</th>
                            <th className='templateName'><div onClick={this.selectSorting}>Template&nbsp;Name{this.state.selectAsc ? <span className='tsort-icon icon-chevron-down-thick' /> : <span className='tsort-icon icon-chevron-up-thick' />}</div></th>
                            <th className='keyword'>Keyword</th>
                            <th className='templateCategory'>Category</th>
                            <th className='lineOfBusiness'>Line of Business</th>
                            <th className='state'>State</th>
                        </tr>
                    </thead>
                    <tbody>{this.renderTableData().length > 0 ? this.renderTableData():null}</tbody>
                </table>
                <div>
                    <div id='tSubHeading2' className="heading-section">
                        Chosen&nbsp;Templates
                </div>
                    <div className='tBorder2' />
                    <table className="stripe fill tableChoosen hideScroll">
                        <thead>
                            <tr>
                                <th className='remove'>Remove</th>
                                <th className='c-templateName'><div onClick={this.chosenSorting}>Template&nbsp;Name{this.state.chosenAsc ? <span className='tsort-icon icon-chevron-down-thick' /> : <span className='tsort-icon icon-chevron-up-thick' />}</div></th>
                                <th className='attachments'>Attachments</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.displayAlert ?
                                <tr>
                                    <td className='sa-icon select'><span className='icon-alert' /></td>
                                    <td className='sa-font' colSpan='3'>
                                        You have reached the maximum number of templates that can be generated in one request. Please remove a template from the list to generate to add a new template.
                                    </td>
                                </tr> : null}
                            {this.renderChosenData()}
                        </tbody>
                    </table>
                </div>
                {this.state.displayModal ? <AddDocumentModal hideModal={this.hideModal} attachTempId={this.state.attachmentTempId} selectedDocs={this.state.attachmentSelected} updateAttachments={this.updateAttachments} claimNumber={this.props.claimNumber} senderId={this.props.senderId}/> : null}
                {this.state.displayAttachmentAlertModal ? <TemplatesDialogModel headerContent={NO_DOCUMENTS_HEADER} bodyContent={NO_DOCUMENTS_BODY} hideTemplateAlertModal={this.hideAttachmentAlertModal} /> : null}
            </div>
        );
    }


    async componentDidMount() {
        let templatesList = null;
        templatesList = await getTemplates();
        this.setState({ selectTemplateList: templatesList, orginalTemplateList: templatesList });

    }

}

async function getTemplates() {
    const templatesList = await getTemplateLists();
    return templatesList;
}

export default SelectionTemplate;