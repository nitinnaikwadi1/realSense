import React, { Component } from 'react';
import App from '../../App';
import AdminPage from '../custom-components/AdminPage';
import { getCommLinkKey } from '../sso/SingleSignOn';

import { updateEnvValues } from '../../constants/GlobalConstants';


class ValidateSSO extends Component {

    constructor(props) {
        super(props);
        this.state = {
            jsonData: '',
            isLoading: true,
            response: null,
            isAdminPage: false,
        }
    }

    render() {

        if (!this.state.isAdminPage) {
            if (this.state.response != null) {
                if (this.state.response.authStatusDivDisplay === 'none' && this.state.response.appDivDisplay === 'inline') {
                    return (<div><App jsonData={this.state.jsonData} /></div>);
                }
                else if (this.state.response.appDivDisplay === 'none' && this.state.response.authStatusDivDisplay === 'inline') {
                    return (<div>Failed Authorization: You are not authorized to access CommLink</div>);
                }
                return (<div></div>);
            }
            else {
                return (<div></div>);
            }
        } else {
            console.log("Admin page");
            return (<AdminPage />);
        }


    }

    async componentDidMount() {
        const jsonData = await getQueryString();
        updateEnvValues(jsonData.env)
        if (jsonData.isDebug !== 'Y')
            console.log = function () { };
        console.log(jsonData);
        var res = await getCommLinkKey();
        if (jsonData.admin === 'true') {
            document.title = 'CommLink - Admin Page';
            this.setState({ isAdminPage: true });

        } else {
            document.title = 'CommLink: ' + jsonData.claimNumber;
            this.setState({ response: res, jsonData: jsonData });
        }

    }
}

async function getQueryString() {
    // Converting this as existing jsonData.. This logic will change after the new url in place
    var pairs = window.location.search.substring(1).split("&");
    var result = {};
    pairs.forEach(function (pair) {
        pair = pair.split('=');
        if (pair[0] === 'claimnum') {
            result['claimNumber'] = decodeURIComponent(pair[1]);
        } else if (pair[0] === 'userName') {
            result['loggedInUser'] = decodeURIComponent(pair[1]);
            result['loggedInUserRole'] = 'Claim Adjuster';
            result['claimUsers'] = [decodeURIComponent(pair[1])];
        } else {
            result[pair[0]] = decodeURIComponent(pair[1]);
        }
    }
    );
    return JSON.parse(JSON.stringify(result));
}

export default ValidateSSO;