import React, { Component } from 'react'
import App from '../../App';
import '../../../assets/css/login-page.css'

class LoginPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            pwd: '',
            DisplayLoginPage: true,
        }
    }

    updateState(ev) {
        this.setState({ DisplayLoginPage: false });
    }

    
    render() {
        if (this.state.DisplayLoginPage) {
            return (
                <div>
                    <div className="input-group column Lname">
                        <div className="input">
                            <input type="text" id="input-name" className="fill" required onChange={(event) => this.setState({ name: event.target.value })} />
                            <label htmlFor="input-name">
                                User Name
                         </label>
                         
                        </div>
                    </div>
                    <div className="input-group column Lpwd">
                        <div className="input">
                            <input type="password" id="password" className="fill" required onChange={(event) => this.setState({ pwd: event.target.value })} />
                            <label htmlFor="password">
                                Password
                         </label>
                        </div>
                    </div>
                    <div className="column twelve text-right sm-four sm-pad-left-10">
                        <button type="submit" className="input-offset Lbutton" onClick={this.updateState.bind(this)}>Go!</button>
                    </div>
                </div>
            );
        } else {
            return (<App user={this.state.name} pwd={this.state.pwd} />);
        }
    }
}

export default LoginPage;