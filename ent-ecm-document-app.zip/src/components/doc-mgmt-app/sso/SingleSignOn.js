import { WS_REGION } from '../../constants/GlobalConstants';

var token;
export async function getCommLinkKey() {
    var url = "https://" + WS_REGION + ".amfam.com/fnolsso/v1/refresh";
    token = getParameterByName("TOKEN");
    console.log(token);
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    if (token) {
        let theURL = window.location.href;
        let newURL = theURL.replace("&TOKEN=" + token, "");
        newURL = newURL.replace("?TOKEN=" + token, "");
        newURL = newURL.replace("&RETRIED=true", "");
        window.history.pushState({}, document.title, newURL);
        myHeaders.append("Authorization", "Bearer " + token);
    }

    return fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: myHeaders
    }).then(response => mapResponse(response))
        .catch(error => console.log("Failed to send " + error));
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    //fixed warning by removing extra as below..name = name.replace(/[\[\]]/g, "\\$&");
    name = name.replace(/[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function mapResponse(response) {
    console.log(response);
    if (response.status === 401) {
        var encoded = window.btoa(window.location);
        var updatedLocation = "https://" + WS_REGION + ".amfam.com/fnolsso/v1/formcreatefnolsso?returnTo=" + encoded;
        window.location = encodeURI(updatedLocation)
    }
    if (response.status === 200) {
        response.authStatusDivDisplay = 'none';
        response.appDivDisplay = 'inline';
        console.log(token);
    }
    else if (response.status === 403) {
        response.appDivDisplay = 'none';
        response.authStatusDivDisplay = 'inline';
    }
    return response;
}

export function getCookie(name) {
    return token;
}