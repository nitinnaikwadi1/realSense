import React, { Component } from "react";
import '../../assets/css/search-params.css'
import DropDown from '../doc-mgmt-app/custom-components/DropDown'
import Modal from './modals/Modal';
import SelectionTemplate from './SelectionTemplate';
import LoadSpinner from '../doc-mgmt-app/custom-components/LoadSpinner';
import MultiDropDown from '../doc-mgmt-app/custom-components/MultiDropDown';


import TemplatesDialogModel from './modals/TemplatesDialogModel';

import { getFullPayLoadXML } from '../../api/services/claim-center/cc-claimdocument/ClaimDocAPIGateway';
import { invokeGenerateDraft } from '../../api/services/smart-comm/GenerateDraftGateway';

import { NO_TEMPLATES_HEADER, NO_TEMPLATES_BODY, ERROR, CC_RESET_HEADER, CC_RESET_BODY, REC_MAX_LIMIT_HEADER, REC_MAX_LIMIT_BODY, TEMPLATE_VALIDATION_HEADER, TEMPLATE_VALIDATION_BODY, SENDER_EMAIL_MISSING_HEADER } from '../constants/AlertConstants';
import { CATEGORIES, OTHER_DELIVERY_TYPE, LOB, LANGUAGES, ALL_EXCEPT, FIRST_CLASS_DELIVERY, EMAIL, UNV_TEMPLATE_STR, ARCHIVE_ONLY, NONE, AND, COLON, YES, NO, CERTIFICATE_DELIVERY, OVERNIGHT_DELIVERY, CERTIFIED_WITH_SIGN_DELIVERY } from '../constants/SelectParamsConst'

class SearchParams extends Component {

    constructor(props) {
        super(props);
        this.state = {
            draftInfo: {
                claimNumber: '',
                senderExternalID: '',
                recipientID: '',
                carbonCopyID: '',
                bccID: '',
                lob: '',
                relatedToID: '',
                relatedToType: '',
                deliveryType: '',
                documentSecurity: '',
                languageId: '',
                otherStateCD: '',
                selectedTemplates: [],
                dualInsuredPartyId: ''
            },
            senderId: '',
            recipientId: 'None',
            ccId: [],
            bccId: [],
            relatedId: 'None',
            deliveryId: 'FIRST CLASS',
            securityId: '',
            languageId: 'ENGLISH',
            otherStateId: '',
            lobId: '',
            selectedTemplates: [],
            show: false,
            reviewCaseObj: '',
            isLoadedStr: false,
            displaySpinner: false,
            isInitialize: true,
            templateFilters: [],
            orginalTemplateList: [],
            deliveryTypes: OTHER_DELIVERY_TYPE,
            languages: LANGUAGES,
            lobs: LOB,
            categories: CATEGORIES,
            states: [],
            stKeywords: '',
            searchTempValue: '',
            draftID: '',
            envelopeID: '',
            respAttachments: '',
            templateArchOnly: '',
            archiveOnly: '',
            approvalLevel: '',
            displayTemplateAlertModal: false,
            showValidationRecipient: false,
            showValidationRelatedTo: false,
            recipientsArrfromAPI: [],
            xmlPayloadFromAPI: '',
            displayRecipientAlertModal: false,
            recipientAlertMessage: '',
            ccResetAlertMessage: '',
            isUnverifiedClaimsFlag: false,
            ccBccMaxlimit: false,
            isTemplateError: false,
            selectedTemplatesArr: [],
            senderAlertMessage: '',
            displaySenderAlertModal: false,
            fullDraftObjResponse: '',
            isDualInsuredPatryPresent: false,
            insuredPartyParticipantId: '',
            dualInsuredPartyId: '',
            dualInsuredPartyName: '',
            displayAddInsuredField: false,
            includeAddInsuredParty: true
        };
        this.handleGenDoc = this.handleGenDoc.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.updateState = this.updateState.bind(this);
        this.updateDefault = this.updateDefault.bind(this);
        this.filterTemplates = this.filterTemplates.bind(this);
        this.templatesElement = React.createRef();
        this.handleReset = this.handleReset.bind(this);
        this.handleKeywordSearch = this.handleKeywordSearch.bind(this);
        this.updateArchiveOnly = this.updateArchiveOnly.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleCCSelection = this.handleCCSelection.bind(this);
        this.BccDropdownElement = React.createRef();
        this.CCDropdownElement = React.createRef();
        this.updateApprovalLevel = this.updateApprovalLevel.bind(this);
        this.setDocumentSecurity = this.setDocumentSecurity.bind(this);
        this.addTemplateAlertModal = this.addTemplateAlertModal.bind(this);
        this.hideTemplateAlertModal = this.hideTemplateAlertModal.bind(this);
        this.clearValidationAlerts = this.clearValidationAlerts.bind(this);
        this.showRecipientAlertModal = this.showRecipientAlertModal.bind(this);
        this.hideRecipientAlertModal = this.hideRecipientAlertModal.bind(this);
        this.showCCResetAlertModal = this.showCCResetAlertModal.bind(this);
        this.hideCCResetAlertModal = this.hideCCResetAlertModal.bind(this);
        this.hideCCBCCAlertModal = this.hideCCBCCAlertModal.bind(this);
        this.hideTemplateErrModal = this.hideTemplateErrModal.bind(this);
        this.handleDualInsuredSelection = this.handleDualInsuredSelection.bind(this);
    }

    showCCResetAlertModal() {
        this.setState({ ccResetAlertMessage: true });
    }
    hideCCResetAlertModal = () => {
        this.setState({ ccResetAlertMessage: false });
    }

    hideTemplateErrModal = () => {
        this.setState({ isTemplateError: false });
    }

    showCCBCCAlertModal = () => {
        this.setState({ ccBccMaxlimit: true });
    }

    hideCCBCCAlertModal = () => {
        this.setState({ ccBccMaxlimit: false });
    }

    showRecipientAlertModal() {
        this.setState({ displayRecipientAlertModal: true });
    }
    hideRecipientAlertModal = () => {
        this.setState({ displayRecipientAlertModal: false });
    }

    addTemplateAlertModal() {
        this.setState({ displayTemplateAlertModal: true });
    }
    hideTemplateAlertModal = () => {
        this.setState({ displayTemplateAlertModal: false });
    }

    async clearValidationAlerts() {
        this.setState({ showValidationRecipient: false, showValidationRelatedTo: false });
    }

    showSenderAlertModal() {
        this.setState({ displaySenderAlertModal: true });
    }
    hideSenderAlertModal = () => {
        this.setState({ displaySenderAlertModal: false, displaySpinner: true }, () => {
            this.callGenerateDraft(this.state.fullDraftObjResponse);
        });
    }

    showModal = () => {
        this.setState({ show: true });
    }

    hideModal = (iscompleted, isFinalized) => {
        if (iscompleted) {
            this.setState({ show: false });
            this.props.showBanner(this.state.draftInfo.selectedTemplates[0].templateName, this.props.recipients[this.props.recipients.findIndex(x => x.id === this.state.recipientId)].displayName, isFinalized);
        } else {
            this.setState({ show: false });
        }

    }

    async updateDefault() {
        // check policy state/ loss state value is present
        var otherStateVal = "";
        if (this.props.claimInfo.policyState !== NONE)
            otherStateVal = this.props.claimInfo.policyState;
        else
            otherStateVal = this.props.claimInfo.lossState;

        this.setState({
            isInitialize: false, senderId: this.props.sender[0].id, lobId: this.props.claimInfo.lob, deliveryId: this.props.deliveryId, templateFilters: this.state.templateFilters, otherStateId: otherStateVal.trim()
        });
    }

    async handleChange(valueObj) {
        if (this.state.isInitialize)
            await this.updateDefault();
        this.setState({ [valueObj.id]: valueObj.value }, () => {
            //disable the delivery type selection if already selected templates present
            if (this.state.selectedTemplates.length !== 0) {
                document.getElementById("deliveryId").disabled = true;
            } else
                document.getElementById("deliveryId").disabled = false;

            // for unverified claims all filters are disabled, so delivey type is also disabled.
            if (this.props.unvOpCo !== undefined && this.props.unvOpCo !== 'null') {
                document.getElementById("deliveryId").disabled = true;
            }

        });
        //handles the template filtering based on selected criteria
        if (valueObj.id === 'categoryId' ||
            valueObj.id === 'otherStateId' ||
            valueObj.id === 'languageId' ||
            valueObj.id === 'lobId' ||
            valueObj.id === 'searchByTemplateKeywordId' ||
            valueObj.id === 'deliveryId') {
            this.filterTemplates(valueObj);
        }

        // BCC selection will reset when delivery type is changed.
        if (valueObj.id === 'deliveryId') {
            this.setState({ bccId: [] }, () =>
                this.BccDropdownElement.current.resetBCCSelectionData()
            );
        }

        // CC selection will reset when delivery type is changed to ARCHIVE ONLY.
        if (valueObj.id === 'deliveryId' && valueObj.value === ARCHIVE_ONLY) {
            var isCCSelected = false;
            if (this.state.ccId.length !== 0)
                isCCSelected = true;

            this.setState({ ccId: [] }, () =>
                this.CCDropdownElement.current.resetCCSelectionData(),
            );
            //as cc are present and being reset then we will show message to adjuster
            if (isCCSelected)
                this.showCCResetAlertModal();
        }

        //handle validation messages
        if (valueObj.id === 'recipientId') {
            this.setState({ showValidationRecipient: false });
        }
        if (valueObj.id === 'relatedId') {
            this.setState({ showValidationRelatedTo: false });
        }

        //check if recipient id is present and dual adjuster party is available
        if(valueObj.id === 'recipientId'){
            if((valueObj.value === this.state.insuredPartyParticipantId || 
                valueObj.value === this.state.dualInsuredPartyId) && 
                this.state.isDualInsuredPatryPresent){
                this.setState({ displayAddInsuredField: true, includeAddInsuredParty : true });
            }
            else    
                this.setState({ displayAddInsuredField: false });
        }
    }

    async updateArchiveOnly(valueObj) {
        //this.state.draftInfo.claimNumber
        this.setState({ templateArchOnly: valueObj.value });
    }

    async updateApprovalLevel(valueObj) {
        this.setState({ approvalLevel: valueObj.value });
    }

    async setDocumentSecurity(valueObj) {
        this.setState({ securityId: valueObj.value });
    }

    async handleCCSelection(valueObj) {
        console.log(valueObj)
        var recipients = [];
        if (valueObj.id === 'ccId' || valueObj.id === 'bccId') {
            if (valueObj.valueArr && valueObj.valueArr.length) {
                recipients = recipients.concat(valueObj.valueArr.map(contact => {
                    return contact.id; // Need to be changed as contact.id
                }));
            }
        }
        console.log(recipients);
        this.setState({ [valueObj.id]: recipients });
    }

    async handleKeywordSearch(valueObj) {
        let objValue = valueObj.target.value;
        console.log(objValue);
        this.setState({ searchTempValue: objValue })
        if (valueObj.target.id === 'searchByTemplateKeywordId') {
            this.filterTemplates({ id: valueObj.target.id, value: objValue });
        }
    }

    async filterTemplates(valueObj) {
        //Filter by language, State, lob, category, template keyword  
        var existingFilters = this.state.templateFilters;
        var updatedFilters = [];
        if (existingFilters.some(val => val.id === valueObj.id)) {
            updatedFilters = [...existingFilters].filter((item) => {
                if (item.id === valueObj.id) {
                    item.value = valueObj.value;
                }
                return item;
            });
        } else {
            updatedFilters =
                this.state.templateFilters.concat({ id: valueObj.id, value: valueObj.value });
        }

        //make sure state id is present by default 
        var checkIfStateIdPresent = updatedFilters.some(item => item.id === 'otherStateId');
        if (!checkIfStateIdPresent) {

            // check policy state/ loss state value is present
            var otherStateVal = "";
            if (this.props.claimInfo.policyState !== NONE)
                otherStateVal = this.props.claimInfo.policyState;
            else
                otherStateVal = this.props.claimInfo.lossState;

            updatedFilters = updatedFilters.concat(
                { id: 'otherStateId', value: otherStateVal });
        }

        //make sure lobId is present by default 
        var checkIfPolicyStateIdPresent = updatedFilters.some(item => item.id === 'lobId');
        if (!checkIfPolicyStateIdPresent) {
            updatedFilters = updatedFilters.concat(
                { id: 'lobId', value: this.props.claimInfo.lobId });
        }

        //make sure deliveryId is present by default 
        var checkIfdeliveryIdPresent = updatedFilters.some(item => item.id === 'deliveryId');
        if (!checkIfdeliveryIdPresent) {
            updatedFilters = updatedFilters.concat(
                { id: 'deliveryId', value: this.state.deliveryId });
        }

        //using callback to access the state after updating
        var defaultFilters = false;
        this.setState({ templateFilters: updatedFilters }, () =>
            //updating the templatesList based on the available filters
            this.updateTemplatesList(defaultFilters, this.state.templateFilters)
        );
    }

    /*E1PCSFCC-1119- For HomeSite UnVerified claims, we need to display only 2 templates(UNV0001, UNV0002) as default filter. */
    async updateUNVTemplatesList() {
        var originalTemplatesList = this.templatesElement.current.state.orginalTemplateList;
        if (this.props.unvOpCo !== undefined && this.props.unvOpCo !== 'null') {
            var filterbyUNVHomesite = [];
            filterbyUNVHomesite = [...originalTemplatesList].filter((item) => {
                if (item.resourceName.trim().startsWith('UNV0')) {
                    // as part of E1PCSFCC-1850
                    // when SPA is launched in email mode we will filter the unverified templates 
                    // which does not have Delivery Type - Email
                    if (this.state.deliveryId === EMAIL) {
                        if ((item.deliveryTypes.toLowerCase().trim().includes
                            (EMAIL.toLowerCase().trim()))) {
                            return item;
                        }
                        return false;
                    }
                    return item;
                }
                return false;
            });
            this.templatesElement.current.renderTemplateData(filterbyUNVHomesite);
        }
    }

    async updateTemplatesList(defaultFilters, filtersList) {
        var originalTemplatesList = this.templatesElement.current.state.orginalTemplateList;
        var filteredTemplatesByLanguage = [];
        var filteredTemplatesByState = [];
        var filteredTemplatesByLob = [];
        var filteredTemplatesByCategory = [];
        var filteredTemplatesByKeyword = [];
        var filteredTemplatesByDeliveryType = [];

        if (defaultFilters) {
            if (this.props.unvOpCo === undefined || this.props.unvOpCo === 'null') {
                filtersList.forEach((val) => {
                    //filter based on language
                    if (val.id === 'languageId') {
                        filteredTemplatesByLanguage = [...originalTemplatesList].filter((item) => {
                            if (item.language.trim() === val.value.trim()) {
                                return item;
                            } return false;
                        });
                    }
                    //filter based on state
                    if (val.id === 'otherStateId') {
                        filteredTemplatesByState = [...filteredTemplatesByLanguage].filter((item) => {
                            if (item.states.trim() === 'ALL') {
                                return item;
                            }
                            if (item.states.trim().includes(ALL_EXCEPT) && !(item.states.trim().includes(val.value.trim()))) {
                                return item;
                            }
                            if (!(item.states.trim().includes(ALL_EXCEPT)) && (item.states.trim().includes(val.value.trim()))) {
                                return item;
                            } return false;
                        });
                    }
                    //filter based on lob
                    if (val.id === 'lobId') {

                        filteredTemplatesByLob = [...filteredTemplatesByState].filter((item) => {
                            if (val.value.trim() === 'ALL' ||
                                (item.lob.trim() === 'ALL' ||
                                    item.lob.toLowerCase().trim().split(',').includes
                                        (val.value.toLowerCase().trim()))) {
                                return item;
                            } return false;
                        });
                    }
                    //filter based on delivery type
                    if (val.id === 'deliveryId') {
                        var selectedDeliveryId = '';
                        if (val.value === 'FIRST CLASS') {
                            selectedDeliveryId = FIRST_CLASS_DELIVERY;
                        }
                        //Removing Certified as part of E1PCSFCC-1634
                        /* if (val.value === 'CERTIFIED') {
                            selectedDeliveryId = CERTIFIED_DELIVERY;
                        } */
                        if (val.value === 'EMAIL') {
                            selectedDeliveryId = EMAIL;
                        }
                        filteredTemplatesByDeliveryType = [...filteredTemplatesByLob].filter((item) => {
                            if ((item.deliveryTypes.toLowerCase().trim().includes
                                (selectedDeliveryId.toLowerCase().trim()))) {
                                return item;
                            } return false;
                        });
                    }
                });
                console.log('Default Template after count:' + filteredTemplatesByDeliveryType.length);
                //E1PCSFCC-1521 - Exclude UNV templates on verified claims
                var finalFilteredTemplates = [...filteredTemplatesByDeliveryType].filter((item) => {
                    if (!(item.resourceName.toUpperCase().trim().startsWith(UNV_TEMPLATE_STR))) {
                        return item;
                    } return false;
                });
                //E1PCSFCC-1521

                this.templatesElement.current.renderTemplateData(finalFilteredTemplates);
            } else {
                this.updateUNVTemplatesList();
            }
        }
        else {
            console.log('Conditional template count before applying selected filter:' + originalTemplatesList.length);

            var filteredTemplatesList = [];
            //filter based on language
            var languageVal = this.state.languageId;
            var mapLobStrings = {
                PLProperty: "Personal Property",
                CLProperty: "Commercial Property",
                FarmRanch: "Farm Ranch",
                CLAuto: "Commercial Auto",
                PLAuto: "Personal Auto"
            };

            filtersList.some(function (val) {
                if (val.id === 'languageId') {
                    filteredTemplatesByLanguage = [...originalTemplatesList].filter((item) => {
                        if (item.language.toLowerCase().trim() === val.value.toLowerCase().trim()) {
                            return item;
                        } return false;
                    });
                } else {
                    //default language is selected, so reading language value from state
                    filteredTemplatesByLanguage = [...originalTemplatesList].filter((item) => {
                        if (item.language.toLowerCase().trim() === languageVal.toLowerCase().trim()) {
                            return item;
                        } return false;
                    });
                }
                filteredTemplatesList = filteredTemplatesByLanguage;
                return false;
            });

            //check if state is selected to be filtered
            var statesToFilter = [];
            filtersList.some(function (val) {
                //filter based on State
                if (val.id === 'otherStateId') {

                    var stateCode = '';
                    if (val.value.includes("Policy") || val.value.includes("Loss")) {
                        stateCode = val.value.slice(val.value.indexOf("-") + 1, val.value.length);
                        statesToFilter = statesToFilter.concat(stateCode.trim());
                    } else
                        statesToFilter = statesToFilter.concat(val.value.trim());
                } return false;
            });


            //states filter is applied for different states selection
            if (statesToFilter.length >= 1) {
                filteredTemplatesByState = [...filteredTemplatesList].filter((item) => {
                    var isStatesFilterApplicable = false;
                    if (item.states.trim() === 'ALL') {
                        return item;
                    }

                    for (var filterdItem of statesToFilter) {
                        var whenAllExceptPresent = item.states.trim().includes(ALL_EXCEPT) && !(item.states.trim().includes(filterdItem.trim()));
                        var whenAllExceptNotPresent = !(item.states.trim().includes(ALL_EXCEPT)) && (item.states.trim().includes(filterdItem.trim()))
                        if (whenAllExceptPresent || whenAllExceptNotPresent) {
                            isStatesFilterApplicable = true;
                            break;
                        }
                    }
                    if (isStatesFilterApplicable) {
                        return item;
                    } return false;
                });

                filteredTemplatesList = filteredTemplatesByState;
            }

            //filter based on lob
            filtersList.some(function (val) {
                if (val.id === 'lobId') {
                    var selectedLobId = val.value.replace(/PLProperty|CLProperty|FarmRanch|CLAuto|PLAuto/gi, function (matched) {
                        return mapLobStrings[matched];
                    });
                    filteredTemplatesByLob = [...filteredTemplatesList].filter((item) => {
                        if (selectedLobId === 'ALL' ||
                            (item.lob.trim().toUpperCase() === 'ALL' ||
                                item.lob.toLowerCase().trim().split(', ').includes(selectedLobId.toLowerCase().trim()))) {
                            return item;
                        } return false;
                    });
                    filteredTemplatesList = filteredTemplatesByLob;
                } return false;
            });
            //filter based on category
            filtersList.some(function (val) {
                if (val.id === 'categoryId' && val.value.trim() !== 'None') {
                    filteredTemplatesByCategory = [...filteredTemplatesList].filter((item) => {
                        if (val.value.trim() === 'None' ||
                            (item.resourceType.trim() === 'ALL' ||
                                item.resourceType.trim().includes(val.value.trim()))) {
                            return item;
                        } return false;
                    });
                    filteredTemplatesList = filteredTemplatesByCategory;
                } return false;
            });

            //filter based on delivery type
            filtersList.some(function (val) {
                if (val.id === 'deliveryId') {

                    var selectedDeliveryId = '';

                    switch (val.value) {
                        case 'OVERNIGHT':
                            selectedDeliveryId = OVERNIGHT_DELIVERY;
                            break;
                        case 'FIRST CLASS':
                            selectedDeliveryId = FIRST_CLASS_DELIVERY;
                            break;
                        case 'EMAIL':
                            selectedDeliveryId = EMAIL;
                            break;
                        case 'CERTIFICATE':
                            selectedDeliveryId = CERTIFICATE_DELIVERY;
                            break;
                        case 'CERTIFIED_W_SIGNATURE':
                            selectedDeliveryId = CERTIFIED_WITH_SIGN_DELIVERY;
                            break;
                        case 'ARCHIVE ONLY':
                            selectedDeliveryId = 'ALL';
                            break;
                        default:
                            selectedDeliveryId = '';
                            break;
                    }
                    //filter is available other than archive
                    filteredTemplatesByDeliveryType = [...filteredTemplatesList].filter((item) => {
                        // as part of [E1PCSFCC-1166]
                        // when delivery type is all we have to filter the EMAIL templates
                        if (selectedDeliveryId === "ALL" &&
                            !item.deliveryTypes.toLowerCase().trim()
                                .includes(EMAIL.toLowerCase().trim())) {
                            return item;
                        }

                        if ((item.deliveryTypes.toLowerCase().trim().includes
                            (selectedDeliveryId.toLowerCase().trim()))) {
                            return item;
                        } return false;
                    });
                    filteredTemplatesList = filteredTemplatesByDeliveryType;
                } return false;
            });

            //filter based on template keywords
            filtersList.some(function (val) {
                if (val.id === 'searchByTemplateKeywordId') {
                    filteredTemplatesByKeyword = [...filteredTemplatesList].filter((item) => {
                        if (item.resourceName.toLowerCase().trim().includes(val.value.toLowerCase().trim()) ||
                            item.states.toLowerCase().trim().includes(val.value.toLowerCase().trim()) ||
                            item.tags.toLowerCase().trim().includes(val.value.toLowerCase().trim()) ||
                            item.resourceType.toLowerCase().trim().includes(val.value.toLowerCase().trim()) ||
                            item.lob.toLowerCase().trim().includes(val.value.toLowerCase().trim())) {
                            return item;
                        } return false;
                    });
                    filteredTemplatesList = filteredTemplatesByKeyword;
                } return false;
            });

            //E1PCSFCC-1521 - Exclude UNV templates on verified claims
            if (this.props.unvOpCo === undefined || this.props.unvOpCo === 'null') {
                var filteredUnverifiedTemplates = [...filteredTemplatesList].filter((item) => {
                    if (!(item.resourceName.toUpperCase().trim().startsWith(UNV_TEMPLATE_STR))) {
                        return item;
                    } return false;
                });
                filteredTemplatesList = filteredUnverifiedTemplates;
            }
            //E1PCSFCC-1521
            //return final filtered templates to component
            console.log('Conditional Template count on screen:' + filteredTemplatesList.length);
            this.templatesElement.current.renderTemplateData(filteredTemplatesList);
        }
    }

    async updateState(isSpinner) {
        var relatedIDArr = this.state.relatedId.split('@');
        let updatedArchOnly = '';
        // Below condition is to take care the UI selection of archive only, rest all based on templates
        if (this.state.deliveryId === 'ARCHIVE ONLY') {
            updatedArchOnly = 'Y';
        } else {
            updatedArchOnly = this.state.templateArchOnly;
        }

        //preserving the default state value from claimInfo API if user don't change the state selection
        var stateCD = '';
        if (this.state.otherStateId === '') {
            // check policy state/ loss state value is present
            var otherStateVal = "";
            if (this.props.claimInfo.policyState !== NONE)
                otherStateVal = this.props.claimInfo.policyState;
            else
                otherStateVal = this.props.claimInfo.lossState;

            stateCD = otherStateVal;
        } else
            stateCD = this.state.otherStateId;

        if (stateCD !== undefined && (stateCD.includes("Policy") || stateCD.includes("Loss"))) {
            stateCD = stateCD.slice(stateCD.indexOf("-") + 1, stateCD.length);
        }

        let draftInfo = {
            ...this.state.draftInfo, claimNumber: this.props.claimInfo.claimNumber,
            senderExternalID: this.state.senderId,
            recipientID: this.state.recipientId,
            carbonCopyID: this.state.ccId,
            bccID: this.state.bccId,
            lob: this.state.lobId, //Default lob
            relatedToID: relatedIDArr[0],
            relatedToType: relatedIDArr[1],
            deliveryType: this.state.deliveryId,
            documentSecurity: this.state.securityId,
            language: this.state.languageId,
            otherStateCD: stateCD,
            selectedTemplates: this.state.selectedTemplates,

        };
        this.setState({ draftInfo: draftInfo, archiveOnly: updatedArchOnly, displaySpinner: isSpinner });
    }

    async handleReset() {
        // check policy state/ loss state value is present
        var otherStateVal = "";
        if (this.props.claimInfo.policyState !== NONE)
            otherStateVal = this.props.claimInfo.policyState;
        else
            otherStateVal = this.props.claimInfo.lossState;

        this.setState({ languages: [], categories: [], lobs: [], states: [], stKeywords: '', languageId: 'ENGLISH', otherStateId: otherStateVal.trim(), lobId: '', searchTempValue: '', templateFilters: [], bccId: [] }, () => {
            // as part of E1PCSFCC-1508 bcc selection will be reset
            this.BccDropdownElement.current.resetBCCSelectionData();
            //E1PCSFCC-1508

            this.setState({ languages: LANGUAGES, categories: CATEGORIES, lobs: LOB, states: this.props.statesArr, stKeywords: '', languageId: 'ENGLISH', otherStateId: otherStateVal.trim(), lobId: 'ALL', searchTempValue: '', templateFilters: [], bccId: [] });
            var defaultTemplateFilters = [
                { id: 'languageId', value: this.state.languageId },
                { id: 'otherStateId', value: otherStateVal },
                { id: 'lobId', value: this.props.claimInfo.lobId },
                { id: 'deliveryId', value: this.state.deliveryId }];
            var defaultFilters = true;
            this.updateTemplatesList(defaultFilters, defaultTemplateFilters);
        }
        );

        // for delivery type reset is applicable when selected templates list is empty
        if (this.state.selectedTemplates.length === 0) {
            this.setState({ deliveryTypes: [], deliveryId: this.props.deliveryId }, () => {
                this.setState({ deliveryTypes: this.props.deliveryTypeList, deliveryId: this.props.deliveryId })
            });
        }
        console.log("Invoking reset to default Search Params");
    }

    handleClose() {
        window.top.close();
    }

    async handleGenDoc(event, value) {
        console.log("CC: " + JSON.stringify(this.state.ccId) + "\n" +
            "BCC: " + JSON.stringify(this.state.bccId));
        console.log("sen:" + this.state.senderId + " rece:" + this.state.recipientId + " ccId:" + this.state.ccId + " bccid:"
            + this.state.bccId + " relatedId:" + this.state.relatedId + " deliveryId:" + this.state.deliveryId + " securityId:" + this.state.securityId + 'templates:' + this.state.draftInfo.selectedTemplates);
        if ((this.state.recipientId === '' || this.state.recipientId === 'None') ||
            (this.state.relatedId === '' || this.state.relatedId === 'None')) {
            if (this.state.recipientId === 'None' && this.state.relatedId === 'None') {
                this.setState({ showValidationRecipient: true, showValidationRelatedTo: true });
            } else if (this.state.recipientId === 'None') {
                this.setState({ showValidationRecipient: true, showValidationRelatedTo: false });
            } else {
                this.setState({ showValidationRecipient: false, showValidationRelatedTo: true });
            }
        } else if (this.state.selectedTemplates === undefined || this.state.selectedTemplates.length === 0) {
            this.addTemplateAlertModal();
        } else if (this.state.relatedId === '' || this.state.relatedId === 'None') {
            this.setState({ showValidationRecipient: false });
            this.setState({ showValidationRelatedTo: true });
        } else {
            await this.updateState(true);
            try {
                var draftObject = await getFullPayLoadXML(this.state.draftInfo, this.state.archiveOnly);
                if (draftObject.status === 'Error') {
                    var messageStr = '';
                    for (var item of draftObject.messages) {
                        messageStr = messageStr + item.message + "\n";
                    }
                    this.setState({ recipientAlertMessage: messageStr, displaySpinner: false }, () => {
                        this.showRecipientAlertModal();
                    });
                } else {
                    //check if sender email is not present cc and show warning to adjuster
                    // this soft warning will be shown only for Delivery Type - "Email"
                    if (this.state.deliveryId === EMAIL &&
                        (draftObject.messageResponse.messages !== undefined
                            && draftObject.messageResponse.messages.length > 0)) {
                        this.setState({ fullDraftObjResponse: draftObject, senderAlertMessage: draftObject.messageResponse.messages[0].message, displaySpinner: false }, () => {
                            this.showSenderAlertModal();
                        });
                    }
                    else {
                        //proceed with draft generation
                        await this.callGenerateDraft(draftObject);
                    }
                }
            } catch (error) {
                console.log(error);
                this.props.isException();
            }
        }
    }

    //draft generation
    async callGenerateDraft(draftObject) {
        var draftStr = draftObject.xmlpayload;
        if (draftStr != null) {
            console.log("calling GenerateDraft");
            var reviewCaseObj = await invokeGenerateDraft(draftStr);
            console.log("Response: " + reviewCaseObj);
            console.log("DraftID: " + draftObject.draftID);
            let isEligibleForModal = true;
            let env = this.props.jsonData.env.toUpperCase();
            //Conditional check for E1PCSFCC-1447 - user story
            if (this.props.jsonData.isDebug !== 'Y' && env !== 'DEV01' && reviewCaseObj.jobMessages !== undefined && reviewCaseObj.jobMessages.length > 0) {
                // the below if-else is temporary logic added to the code as per business request. once the storage is fixed, it will be removed.
                if (reviewCaseObj.jobMessages.length === 1 && reviewCaseObj.jobMessages[0].msgText._text.includes('sc-claims-storage-attachment')) {
                    isEligibleForModal = true;
                }
                else {
                    this.setState({ displaySpinner: false, isTemplateError: true });
                    isEligibleForModal = false;
                }
            }
            if (isEligibleForModal) {
                this.setState({ reviewCaseObj: reviewCaseObj, isLoadedStr: true, displaySpinner: false, draftID: draftObject.draftID, envelopeID: draftObject.envelopeID, respAttachments: draftObject.attachments, recipientsArrfromAPI: draftObject.recipients, xmlPayloadFromAPI: draftObject.xmlpayload, selectedTemplatesArr: draftObject.selectedTemplates });
                this.showModal();
            }
        }
    }


    componentDidMount() {
        this.updateState(false);
    }

    componentDidUpdate(prevProps) {
        if (this.state.isInitialize) {
            if (this.props.claimInfo !== '') {
                // as part of [E1PCEOSOC-434] - check policy state/ loss state value is present
                var otherStateVal = "";
                if (this.props.claimInfo.policyState !== NONE)
                    otherStateVal = this.props.claimInfo.policyState;
                else
                    otherStateVal = this.props.claimInfo.lossState;

                //load templates based on default filter criteria
                var defaultTemplateFilters = [
                    { id: 'languageId', value: this.state.languageId },
                    { id: 'otherStateId', value: otherStateVal },
                    { id: 'lobId', value: this.props.claimInfo.lobId },
                    { id: 'deliveryId', value: this.props.deliveryId }];
                var defaultFilters = true;
                this.updateTemplatesList(defaultFilters, defaultTemplateFilters);
                if (prevProps.statesArr !== this.props.statesArr) {
                    //flag is maintained to enable/ disable filter criteria
                    var isUnverifiedClaim = false;
                    if (this.props.unvOpCo !== undefined && this.props.unvOpCo !== 'null') {
                        isUnverifiedClaim = true;
                        document.getElementById("deliveryId").disabled = true;
                        document.getElementById("searchByTemplateKeywordId").disabled = true;
                        document.getElementById("categoryId").disabled = true;
                        document.getElementById("lobId").disabled = true;
                        document.getElementById("otherStateId").disabled = true;
                        document.getElementById("languageId").disabled = true;
                    }

                    //disable Sender selection as part of E1PCSFCC-1634
                    document.getElementById("senderId").disabled = true;

                    //check for insured party as well as dual insured recipient
                    var isDualInsuredPatryPresent = false;
                    var dualInsuredPartyName = '';
                    var insuredPartyId = '';
                    var dualInsuredPartyId = '';
                    for (var recipient of this.props.recipients) {
                        if (recipient.isInsuredParty) {
                            insuredPartyId = recipient.id;
                            dualInsuredPartyName = recipient.displayName.slice(recipient.displayName.indexOf(COLON) + 1, recipient.displayName.length);
                        }
                        if (recipient.isDualInsuredParty) {
                            isDualInsuredPatryPresent = true;
                            dualInsuredPartyName = dualInsuredPartyName + AND + recipient.displayName.slice(recipient.displayName.indexOf(COLON) + 1, recipient.displayName.length);
                            dualInsuredPartyId = recipient.id;

                        }
                    }
                    let draftInfo = {
                        ...this.state.draftInfo,
                        dualInsuredPartyId: dualInsuredPartyId,
                    };

                    this.setState({
                        states: this.props.statesArr, deliveryId: this.props.deliveryId,
                        deliveryTypes: this.props.deliveryTypeList, isUnverifiedClaimsFlag: isUnverifiedClaim,
                        isDualInsuredPatryPresent: isDualInsuredPatryPresent, dualInsuredPartyName: dualInsuredPartyName, insuredPartyParticipantId: insuredPartyId, dualInsuredPartyId: dualInsuredPartyId, draftInfo: draftInfo
                    }, () => {
                        if (this.props.deliveryId === 'EMAIL') {
                            let claimObj = this.props.relatedTo.filter(obj => obj.displayName === 'Claim');
                            this.handleChange({ id: "relatedId", value: claimObj[0].id });
                            //setting default template for Delivery Type - Email
                            this.templatesElement.current.setDefaultForEmailDelivery();
                        }
                    });

                }
            }
        }
    }

    async handleDualInsuredSelection(valueObj) {
        if (valueObj.value === YES) {
            let draftInfo = {
                ...this.state.draftInfo,
                dualInsuredPartyId: this.state.dualInsuredPartyId,

            };
            this.setState({ includeAddInsuredParty: true, draftInfo: draftInfo });
        }
        else {
            let draftInfo = {
                ...this.state.draftInfo,
                dualInsuredPartyId: '',
            };
            this.setState({ includeAddInsuredParty: false, draftInfo: draftInfo });
        }
    }

    render() {
        const sender = this.props.sender;
        var recipients = this.props.recipients;
        var claimInfo = this.props.claimInfo;
        var relatedTo = this.props.relatedTo;

        // check for unwanted prefix when dual insured is not present
        var checkDualInsuredParty = false;
        for (var recipient of recipients) {
            if (recipient.isDualInsuredParty === true) {
                checkDualInsuredParty = true;
                break;
            }
        }
        if (!checkDualInsuredParty) {
            for (var recipientData of recipients) {
                if(recipientData.isInsuredParty === true){
                    recipientData.displayName = recipientData.displayName.slice(recipientData.displayName.indexOf(COLON) + 1, recipientData.displayName.length);
                    break;
                }
            }
        }

        return (
            <div>
                <div id='spsubHeading1'>
                    Correspondence Information
                </div>
                <div className="row">
                    <div className="input-group recipents">
                        <ValidationBannerRecipient showValidationRecipient={this.state.showValidationRecipient} />
                        <DropDown id='recipientId' optionData={recipients} Title={'Recipient'} handleChange={this.handleChange} required='true' isValidInputPresent={this.state.recipientId} isInitial={this.state.isInitialize} />
                    </div>
                    <div className="input-group cc">
                        <MultiDropDown id='ccId' options={recipients} Title={'CC'}
                            handleCCSelection={this.handleCCSelection} deliveryType={this.state.deliveryId}
                            ref={this.CCDropdownElement} selectedLimit={this.state.bccId.length} showCCBCCAlertModal={this.showCCBCCAlertModal} />
                    </div>
                    <div className="input-group bcc">
                        <MultiDropDown id='bccId' options={recipients} Title={'BCC'}
                            handleCCSelection={this.handleCCSelection} deliveryType={this.state.deliveryId}
                            ref={this.BccDropdownElement} selectedLimit={this.state.ccId.length} showCCBCCAlertModal={this.showCCBCCAlertModal} />
                    </div>
                </div>
                {this.state.displayAddInsuredField ?
                    <div className="input-group column recipentsDualInsured" onChange={e => { this.handleDualInsuredSelection({ id: this.props.id, value: e.target.value }); }}>
                        <legend>
                            Include both insureds, {this.state.dualInsuredPartyName}, on the salutation?
                    </legend>
                        <input className="insured-radio" name="insured" type="radio" id="dualInsuredYes" value={YES} checked={this.state.includeAddInsuredParty} />
                        <label htmlFor="dualInsured-yes">
                            Yes
                        </label>
                        <input className="insured-radio" name="insured" type="radio" id="dualInsuredNo" value={NO}
                        />
                        <label htmlFor="dualInsured-no">
                            No
                        </label>
                    </div> : null}

                <div className="row">
                    <div className="input-group delivery-type">
                        <DropDown id='deliveryId' optionData={this.state.deliveryTypes} Title={'Delivery Type'} handleChange={this.handleChange} required='true' />
                    </div>
                    <div className="input-group related-to">
                        <ValidationBannerRelatedTo showValidationRelatedTo={this.state.showValidationRelatedTo} />
                        <DropDown id='relatedId' optionData={relatedTo} Title={'Related To'} handleChange={this.handleChange} required='true' isValidInputPresent={this.state.relatedId} isInitial={this.state.isInitialize} />
                    </div>
                </div>
                <div className="row">
                    <div className="input-group sender">
                        <DropDown id='senderId' optionData={sender} Title={'Sender'} handleChange={this.handleChange} />
                    </div>
                </div>
                <div className='spBorder2' />
                <div id='spsubHeading2'>
                    Templates
                </div>
                <div className='spBorder3' />
                <div className="input-group column search">
                    <div className="input">
                        <input type="search" id="searchByTemplateKeywordId" className="icon fill"
                            onChange={this.handleKeywordSearch} value={this.state.searchTempValue} /><span className="icon-search-compass"></span>
                        <label htmlFor="input-email">Search Template</label>
                    </div>
                </div>

                <div className="input-group column category">
                    <DropDown id='categoryId' optionData={this.state.categories} Title={'Category'} handleChange={this.handleChange}
                        filterTemplates={this.filterTemplates} />
                </div>
                <div className="input-group column lob">
                    <DropDown id='lobId' optionData={this.state.lobs} Title={'Line of Business'} handleChange={this.handleChange}
                        filterTemplates={this.filterTemplates} />
                </div>
                <div className="input-group column otherState">
                    <DropDown id='otherStateId' optionData={this.state.states} Title={'State'} handleChange={this.handleChange} filterTemplates={this.filterTemplates} />
                </div>
                <div className="input-group column language">
                    <DropDown id='languageId' optionData={this.state.languages} Title={'Language'} handleChange={this.handleChange}
                        filterTemplates={this.filterTemplates} />
                </div>
                <div className="input-group column reset-filter">
                    <button className='outline white' onClick={this.handleReset} disabled={this.state.isUnverifiedClaimsFlag}>Reset&nbsp;Filters</button>
                </div>
                <div className='finalBorder' />
                <div id='generateDoc'>
                    <button className='outline blue' onClick={this.handleGenDoc}>Generate Document</button>
                </div>
                <SelectionTemplate id='selectedTemplates' handleChange={this.handleChange} threshold={this.props.threshold}
                    filterTemplates={this.filterTemplates} ref={this.templatesElement} updateArchiveOnly={this.updateArchiveOnly} documentList={this.props.documentList} claimNumber={claimInfo.claimNumber} updateApprovalLevel={this.updateApprovalLevel} setDocumentSecurity={this.setDocumentSecurity} clearValidationAlerts={this.clearValidationAlerts} senderId={this.state.senderId} />
                <div>
                    <Modal show={this.state.show} reviewCaseObj={this.state.reviewCaseObj} isLoadedStr={this.state.isLoadedStr} hideModal={this.hideModal} displaySpinner={this.state.displaySpinner} claimNumber={this.state.draftInfo.claimNumber} deliveryType={this.state.draftInfo.deliveryType} draftID={this.state.draftID} archiveOnly={this.state.archiveOnly} isException={this.props.isException} approvalLevel={this.state.approvalLevel} respAttachments={this.state.respAttachments} senderID={this.state.draftInfo.senderExternalID} recipientsDataArr={this.state.recipientsArrfromAPI} xmlPayload={this.state.xmlPayloadFromAPI} selectedTemplatesArr={this.state.selectedTemplatesArr}>
                    </Modal>
                </div>
                <LoadSpinner isLoading={this.props.isLoading} contentText='Refreshing...' />
                {this.state.displayTemplateAlertModal ? <TemplatesDialogModel headerContent={NO_TEMPLATES_HEADER} bodyContent={NO_TEMPLATES_BODY} hideTemplateAlertModal={this.hideTemplateAlertModal} /> : null}
                {this.state.displayRecipientAlertModal ? <TemplatesDialogModel headerContent={ERROR} bodyContent={this.state.recipientAlertMessage} hideTemplateAlertModal={this.hideRecipientAlertModal} /> : null}
                {this.state.ccResetAlertMessage ? <TemplatesDialogModel headerContent={CC_RESET_HEADER} bodyContent={CC_RESET_BODY} hideTemplateAlertModal={this.hideCCResetAlertModal} /> : null}
                {this.state.ccBccMaxlimit ? <TemplatesDialogModel headerContent={REC_MAX_LIMIT_HEADER} bodyContent={REC_MAX_LIMIT_BODY} hideTemplateAlertModal={this.hideCCBCCAlertModal} /> : null}
                {this.state.isTemplateError ? <TemplatesDialogModel headerContent={TEMPLATE_VALIDATION_HEADER} bodyContent={TEMPLATE_VALIDATION_BODY} hideTemplateAlertModal={this.hideTemplateErrModal} /> : null}
                {this.state.displaySenderAlertModal ? <TemplatesDialogModel headerContent={SENDER_EMAIL_MISSING_HEADER} bodyContent={this.state.senderAlertMessage} hideTemplateAlertModal={this.hideSenderAlertModal} /> : null}
            </div>
        );
    }
}

function ValidationBannerRecipient(props) {
    if (!props.showValidationRecipient) {
        return null;
    }
    return (
        <div className="validation" style={{ display: 'inline-block' }}>
            <label>
                Please enter the required data in "Recipient"
        </label>
        </div>
    );
}

function ValidationBannerRelatedTo(props) {
    if (!props.showValidationRelatedTo) {
        return null;
    }
    return (
        <div className="validation" style={{ display: 'inline-block' }}>
            <label>
                Please enter the required data in "Related To"
        </label>
        </div>
    );
}

export default SearchParams; 