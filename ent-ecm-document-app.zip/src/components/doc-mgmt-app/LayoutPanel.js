import React, { Component } from "react";
import '../../assets/css/layout-panel.css'
import Header from '../doc-mgmt-app/custom-components/Header'
import SearchParams from '../doc-mgmt-app/SearchParams';
import LoadSpinner from '../doc-mgmt-app/custom-components/LoadSpinner';
import { invokeClaimsAPI } from '../../api/services/claim-center/ClaimServiceAPI';

import { COMPLETION_ALERT_MSG, COMPLETE_CLOSE_MSG, SAVED_ALERT_MSG } from '../constants/AlertConstants';
import { STATES, NONE } from '../constants/SelectParamsConst';

class LayoutPanel extends Component {

    constructor(props) {
        super(props);
        this.state = {
            claimInfo: '',
            recipients: '',
            senderInfo: '',
            relatedTo: '',
            isRefresh: '',
            isLoading: false,
            isFinalized: false,
            isDisplayBanner: false,
            recipientName: '',
            templateName: '',
        }
        this.showCompleteBanner = this.showCompleteBanner.bind(this);
    }


    showCompleteBanner(templateName, recipientName, isFinalized) {
        this.setState({ isFinalized: isFinalized, recipientName: recipientName, templateName: templateName, isDisplayBanner: true });
    }

    UNSAFE_componentWillMount() {
        this.setState({ claimInfo: this.props.claimInfo, recipients: this.props.recipients, relatedTo: this.props.relatedTo, senderInfo: this.props.senderInfo });
    }

    async reloadClaimsDetails() {
        this.setState({ isLoading: true });
        console.log('Refreshing: ' + this.state.isLoading);
        try {
            let claimsResp = await invokeClaimsAPI(this.props.headerData.claimNumber, this.props.headerData.mode);
            this.setState({ claimInfo: claimsResp.claimInfo, senderInfo: claimsResp.senderInfo, recipients: claimsResp.recInfo, isRefresh: true, relatedTo: claimsResp.relatedTo, isLoading: false });
        } catch (error) {
            this.props.isException();
        }
    }

    render() {
        const headerData = this.props.headerData;
        var recipients = this.state.isRefresh ? this.state.recipients : this.props.recipients;
        var claimInfo = this.state.isRefresh ? this.state.claimInfo : this.props.claimInfo;
        var relatedTo = this.state.isRefresh ? this.state.relatedTo : this.props.relatedTo;
        var deliveryTypeId = headerData.mode === 'email' ? 'EMAIL' : 'FIRST CLASS';
        var statesArr=[];
        if(claimInfo !== ''){
            //as part of [E1PCEOSOC-434] - if policy state is not present we will not include that in states list
            var policyState="";
            var stateFromClaimInfo = [];
            const lossState = claimInfo.lossState;

            if(claimInfo.policyState !== NONE){
                policyState = claimInfo.policyState;
                stateFromClaimInfo = [{ 'id': 'Policy-'+policyState, 'displayName': 'Policy State: '+policyState, 'selected': true },{ 'id': 'Loss-'+lossState, 'displayName': 'Loss State: '+lossState , 'selected': false }];
            }else{
                stateFromClaimInfo = [{ 'id': 'Loss-'+lossState, 'displayName': 'Loss State: '+lossState , 'selected': true }];
            }
            
            //needs to filter duplicate states as we have combined policy and loss state values with states value
            var filteredStatesArr = STATES.filter(item => {
                if (item.id.trim() !== policyState || item.id.trim() !== lossState) {
                    return item;
                }
                return false;
            });
            statesArr = stateFromClaimInfo.concat(filteredStatesArr);
        } 
        // Initial load will be empty, hence added the empty check.
        if (headerData !== '') {
            var senderInfo = [{ 'id': headerData.userID, 'displayName': headerData.loggedInUser, 'selected': true }];
            var senders = this.state.isRefresh ? this.state.senderInfo : this.props.senderInfo;
            if (senders !== undefined) {
                senders = senders.filter(function (item) {
                    return item.contactID.split('@')[1] !== headerData.userID;
                });
                senderInfo = senderInfo.concat(senders.map(user => {
                    let publicID = user.contactID.split('@');
                    return {
                        'id': publicID[1], 'displayName': user.displayName, 'selected': false
                    }
                }));
            }
        }
        return (
            <div id='container-parent'>
                <div id='container'>
                    <Header headerData={headerData} />
                    <CompletionBanner stateProps = {this.state}></CompletionBanner>
                    <div id='spHeader'>
                        New&nbsp;Correspondence
                        </div>
                    <div className='spBorder1'></div>
                    <div id='refresh'>
                        <button className="outline white icon-refresh-reset" onClick={this.reloadClaimsDetails.bind(this)}>  Refresh</button>
                    </div>
                    <SearchParams sender={senderInfo} recipients={recipients} claimInfo={claimInfo} relatedTo={relatedTo} isLoading={this.state.isLoading} threshold={headerData.threshold} documentList={this.props.documentList} isException={this.props.isException} unvOpCo={headerData.unvOpCo} showBanner={this.showCompleteBanner} statesArr={statesArr} deliveryId={deliveryTypeId} deliveryTypeList = {this.props.deliveryType} jsonData={this.props.jsonData}/>
                    <LoadSpinner isLoading={this.props.isLoading} contentText='Loading...' />
                </div>
            </div>
        );
    } //End of Return       
}

function CompletionBanner(props) {
    if (props.stateProps.isDisplayBanner) {
        if (props.stateProps.isFinalized) {
            let completionAlert = COMPLETION_ALERT_MSG.replace('[Document Name]', props.stateProps.templateName).replace('[Recipient]', props.stateProps.recipientName)
            return (<div className='complete-banner'>
                <span className='complete-icon icon-star'></span>
                <div className='complete-text '>{completionAlert}
                    <div className='complete-ctext'>{COMPLETE_CLOSE_MSG}</div>
                </div>
            </div>
            );
        } else {
            return (<div className='complete-banner'>
                <span className='complete-icon icon-star'></span>
                <div className='save-text'>{SAVED_ALERT_MSG}</div>
            </div>
            );;
        }
    } else {
        return null;
    }

}

export default LayoutPanel;