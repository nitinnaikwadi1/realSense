import React, { Component } from "react";
import PropTypes from "prop-types";
import Select, { components } from "react-select";
import { EMAIL, NONE, ARCHIVE_ONLY } from "../../constants/SelectParamsConst";

const Option = props => (

  <div>
    <components.Option {...props}>
      <input type="checkbox" checked={props.isSelected} onChange={() => null} />{" "}
      <label>{props.label}</label>
    </components.Option>
  </div>
);

const MultiValue = props => (
  <components.MultiValue {...props}>
    <span>{props.data.label}</span>
  </components.MultiValue>
);

class MultiSelectDropDown extends Component {

  state = {
    selectedOptions: []
  };

  onInputChange = selected => {
    console.log(this.state.selectedOptions);
    this.setState({ selectedOptions: selected });
    this.props.handleCCSelection({ id: this.props.id, valueArr: selected })
  };

  static propTypes = {
    options: PropTypes.arrayOf(
      PropTypes.shape({
        value: PropTypes.node,
        label: PropTypes.node
      })
    ).isRequired,
    onChangeCallback: PropTypes.func.isRequired
  };

  static defaultProps = {
    options: []
  };


  resetBCCSelectionData() {
    this.setState({ selectedOptions: [] });
  }

  resetCCSelectionData() {
    this.setState({ selectedOptions: [] });
  }

  render() {
    const { selectedOptions } = this.state;
    const { options, deliveryType, onChangeCallback, ...otherProps } = this.props;
    let optionId = this.props.id;
    var optionsData = [];
    optionsData = options.filter((item) => {
      if (item.displayName !== NONE) {
        return item;
      }
    });

    var carbonCopyIds = [];
    if (options.length >= 1) {
      carbonCopyIds = carbonCopyIds.concat(optionsData.map(contact => {
        return {
          "value": contact.id, "label": contact.displayName,
          "selected": false
        };
      }));
    }
    var placeholder = '';
    var isDisabled = false;
    if (this.props.id === 'ccId') {
      placeholder = 'CC';
      //alert(deliveryType);
      if (deliveryType !== undefined && deliveryType === ARCHIVE_ONLY) {
        isDisabled = true;
      }
    }
    if (this.props.id === 'bccId') {
      placeholder = 'BCC';
      if (deliveryType !== undefined && deliveryType !== EMAIL) {
        isDisabled = true;
      }
    }

    const customStyles = {
      menu: (provided, state) => ({
        ...provided,
        color: '#003DA5'
      }),
      control: (provided, state) => ({
        ...provided,
        background: '#fff',
        minHeight: '33px',
        height: '33px',
        borderRadius: 2,
        boxShadow: state.isFocused ? null : null
      }),
      valueContainer: (provided, state) => ({
        ...provided,
        height: '33px',
        padding: '0 6px',
        backgroundColor: state.isDisabled
          ? '#ededed'
          : ''
      }),

      indicatorSeparator: state => ({
        display: 'none',
      }),

      dropdownIndicator: (provided, state) => ({
        ...provided,
        height: '33px',
        padding: '0 6px',
        backgroundColor: state.isDisabled
          ? '#ededed'
          : '',
        padding: 5
      }),

    };

    return (
      <Select
        styles={customStyles}
        id={this.props.id}
        closeMenuOnSelect={false}
        isMulti
        placeholder={placeholder}
        components={{ Option, MultiValue }}
        defaultValue={selectedOptions}
        value={selectedOptions}
        onChange={this.onInputChange}
        options={carbonCopyIds}
        isSearchable={false}
        isDisabled={isDisabled}
        hideSelectedOptions={false}
        backspaceRemovesValue={false}
        {...otherProps}
      />);
  }
}

export default MultiSelectDropDown;