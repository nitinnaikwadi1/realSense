import React, { Component } from "react";
import '../../../assets/css/accordion.css'

class Accordion extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
        }
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick() {
        this.setState({ isOpen: !this.state.isOpen });
    };

    renderTableData() {
        console.log(this.props.errorInfo);
        return (
            <table>
                <tbody className="hideScroll">
                    {this.props.errorInfo !== '' ? this.props.errorInfo.map((message, index) => {
                        return (
                            <tr className='accordion-border'>
                                <td className='accordion-w-icon select'><span className='icon-alert' /></td>
                                <td className='DraftAlertMsgText'>
                                    <div>Msg Text:{message.msgText._text}</div>
                                </td>
                            </tr>                            
                        )
                    }) : null}
                </tbody>
            </table>
        );
    }

    render() {
        console.log(this.props.errorInfo);
        return (
            this.props.errorInfo !== undefined ?
                <div>
                    <div className='accordion-header' onClick={this.handleClick}>
                        This document has {this.props.errorInfo.length} alerts {this.state.isOpen ? <span className='arrow-display icon-chevron-down-thick' /> : <span className='arrow-display icon-chevron-up-thick' />}
                    </div>
                    {this.state.isOpen ? <div className='accordion-body' >{this.renderTableData()}</div> : null}
                </div> : null);
    }
}

export default Accordion;