import React from 'react';

class DropDown extends React.Component {

    render() {
        const optionData = this.props.optionData;
        let options = null;
        let optionId = this.props.id;
        var isInvalidInput = "input";
        if (Array.isArray(optionData)) {
            options = optionData.map((option) => {
                if (option.selected === true)
                    return <option key ={option.id} value={option.id} selected>{option.displayName}</option>                   
                else
                    return <option key ={option.id} value={option.id}>{option.displayName}</option>
            });
        }

        if (typeof (this.props.required) !== undefined && this.props.required === 'true') {
            var requiredTag = <span className="required"><b>*</b></span>;
        }

        //check for validation fields
        if((this.props.id === 'recipientId' && this.props.isValidInputPresent==='None') ||
            (this.props.id === 'relatedId' && this.props.isValidInputPresent==='None')){
                if(!this.props.isInitial){
                    isInvalidInput = "invalid input";
                }else
                isInvalidInput = "input";
        }

        return (<div className={isInvalidInput}>
            <select id={this.props.id} className="icon fill" onChange={e => {
                this.props.handleChange({id:this.props.id, value:e.target.value});
            }}>
                {options}
            </select>
            <span className="icon-chevron-down"></span>
            <label htmlFor={"label-" + optionId} >
                {this.props.Title}
                {requiredTag}
            </label>
        </div>);
    }
}

export default DropDown;