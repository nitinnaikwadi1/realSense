import React from "react";
import '../../../assets/css/admin-page.css';
import LoadSpinner from "../custom-components/LoadSpinner";
import {int01_getTemplatesJSON} from '../../../api/services/smart-comm/listAllTemplatesAPI'


class AdminPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isClicked: false,
            isLoading: false,
            jsonValue:'',
        };
        this.handleRefresh = this.handleRefresh.bind(this);
    }

    async handleRefresh() {
        this.setState({ isClicked: true, isLoading:true });
        let response = await int01_getTemplatesJSON();
        let folders = JSON.stringify(response);
        this.setState({isLoading: false, jsonValue: folders});
    }

    render() {
        return (
            <div className='a-container'>
                <div className="header">
                    <div className='column a-commlink'>COMMLINK</div>
                    <div className='column a-heading-section a-claimInfo'>Admin Page</div>
                    <div className='a-headerLine'></div>
                </div>
                <div className='a-body-heading'>Welcome User</div>
                <div className='a-body-question'>Do you want to refresh template folders?</div>
                <div className='a-body-selection'>
                    <button className="outline white" onClick={this.handleRefresh}>
                        Yes
                    </button>
                </div>
                {this.state.isClicked ? <textarea className="textarea-json" value={this.state.jsonValue} readOnly></textarea> : null}
                <LoadSpinner isLoading={this.state.isLoading} contentText='Loading...' />
            </div>
        );

    }
}

export default AdminPage;