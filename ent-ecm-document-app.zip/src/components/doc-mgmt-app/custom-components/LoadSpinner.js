import React from 'react';

class LoadSpinner extends React.Component {
    render() {
        if (this.props.isLoading) {
            return (
                <div className='overlay-black modal-back-hide'>
                    <div className="loading-container spinner-container">
                        <div className="box">
                            <div className="spinner"></div>
                            <div className="heading-main">
                                {this.props.contentText}
                            </div>
                        </div>
                    </div>
                </div>
            );
        } else {
            return (<div></div>);
        }
    }
}

export default LoadSpinner;