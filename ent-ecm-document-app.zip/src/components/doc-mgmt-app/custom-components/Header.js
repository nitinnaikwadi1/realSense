import React, { Component } from "react";
import homesiteLogo from '../../../assets/images/HomesiteLogo.png'
import '../../../assets/css/header.css';


class Header extends Component {
    render() {
        const headerData = this.props.headerData;
        return (
            <div>
                <div className='logo'><img src={homesiteLogo} alt='LOGO' /></div>
                <div className="header">
                    <div className='column pipe-link'>|</div>
                    <div className='column commlink'>COMMLINK</div>
                    <div className='column heading-section claimInfo'>Claim&nbsp;#:&nbsp;{headerData.claimNumber}</div>
                    <div className='column heading-sub-section userTitle'>
                        <span className=" icon-profile"></span>
                        &nbsp;&nbsp;{headerData.loggedInUser}
                    </div>
                    <div className='headerLine'></div>
                    {/*  <div id='roleTitle' className='column'>
               &nbsp;&nbsp;{headerData.loggedInUserRole}
                  </div>  */}
                </div>
            </div>
        );
    } //End of Return   
}

export default Header;