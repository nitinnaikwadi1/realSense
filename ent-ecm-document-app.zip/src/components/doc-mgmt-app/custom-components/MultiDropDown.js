import React from 'react';
import '../../../assets/css/multi-dropdown.css'
import '../../../assets/css/search-params.css'

import { EMAIL, NONE, ARCHIVE_ONLY, CC_BCC_MAX_LIMIT } from "../../constants/SelectParamsConst";


class MultiDropDown extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            selectedContacts: [],
            exceededLimit:false,

        }
        this.handleClick = this.handleClick.bind(this);
        this.updateSelectedContacts = this.updateSelectedContacts.bind(this);
        this.handleOutsideClick = this.handleOutsideClick.bind(this);
    }

    resetBCCSelectionData() {
        this.setState({ selectedContacts: [] });
    }

    resetCCSelectionData() {
        this.setState({ selectedContacts: [] });
    }


    valueChanged(){
        //onchange event called.
    }

    handleClick() {
        if (!this.state.isOpen) {
            // Event handler to detect outsideclick
            document.addEventListener('click', this.handleOutsideClick, false);
        } else {
            document.removeEventListener('click', this.handleOutsideClick, false);
        }
        this.setState({ isOpen: !this.state.isOpen, exceededLimit:false });
    };

    handleOutsideClick(e) {
        // ignore clicks on the component itself
        if (this.node.contains(e.target)) {
            return;
        }
        let totalSelected = this.props.selectedLimit + this.state.selectedContacts.length;
        if (totalSelected > CC_BCC_MAX_LIMIT) {
            let removeLastSelected = this.state.selectedContacts;
            removeLastSelected.pop();
            this.setState({ selectedContacts: removeLastSelected })
        }
        this.handleClick();
    }

    updateSelectedContacts(contact) {
        let updatedContacts = this.state.selectedContacts;
        let index = updatedContacts.findIndex(item => item.id === contact.id);
        if (index !== -1) {
            updatedContacts.splice(index, 1);
        }
        else
            updatedContacts.push(contact);
        this.setState({ selectedContacts: updatedContacts });
        let totalSelected = this.props.selectedLimit + updatedContacts.length;
        if (totalSelected <= CC_BCC_MAX_LIMIT) {
            this.props.handleCCSelection({ id: this.props.id, valueArr: updatedContacts })
        } else {
            this.setState({exceededLimit:true});
            this.props.showCCBCCAlertModal()
        }
    }

    renderDropdown() {
        return (
            <div >
                {this.props.options.map((contact, index) => {
                    let cIndex = this.state.selectedContacts.findIndex(item => item.id === contact.id);
                    let isChecked = cIndex !== -1 ? true : false;
                    if (contact.displayName !== NONE)
                        return (
                            <div key={index}>
                                <input className="input-textAlign" type='checkbox' id={index} defaultChecked={isChecked} onClick={this.updateSelectedContacts.bind(this, contact)} value={contact.displayName} /> {contact.displayName}
                            </div>
                        )
                    else
                        return null;
                })}
            </div>
        );
    }

    handleMouseDown = (e) => {
        if (this.node.contains(e.target)) {
            return;
        }
        this.setState({ isOpen: !this.state.isOpen });
    }

    isDropdownDisable() {
        let isDisabled = false;
        if (this.props.id === 'ccId') {
            if (this.props.deliveryType !== undefined && this.props.deliveryType === ARCHIVE_ONLY) {
                isDisabled = true;
            }
        }
        if (this.props.id === 'bccId') {
            if (this.props.deliveryType !== undefined && this.props.deliveryType !== EMAIL) {
                isDisabled = true;
            }
        }
        return isDisabled;
    }

    render() {
        let isDisabled = this.isDropdownDisable();
        let dropdownDivId = isDisabled ? 'icon m-input-text m-input-text-disable' : 'icon m-input-text';
        let dropdownBodyId = this.state.exceededLimit ? 'm-dropdown-body' : 'm-dropdown-body mdb-zindex';
        let displayName = ' ';
        if (this.state.selectedContacts.length !== 0) {
            let contactNames = [];
            this.state.selectedContacts.forEach(item => contactNames.push(item.displayName));
            displayName = contactNames.join(', ');
        }
        return (
            <div className="input" ref={node => this.node = node} >
                <input type="text" onClick={this.handleClick} onChange={this.valueChanged} className={dropdownDivId} value={displayName} disabled={isDisabled} /> <span className="icon-chevron-down" />
                <label htmlFor='input-multi' className='m-select-text'>
                    {this.props.Title}
                </label>
                {this.state.isOpen ? <div className={dropdownBodyId}>{this.renderDropdown()}</div> : null}
            </div >
        );
    }
}

export default MultiDropDown;