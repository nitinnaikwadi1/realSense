import React from 'react';
import DropDown from '../custom-components/DropDown';
import '../../../assets/css/doc-modal.css'
import { getDocuments } from '../../../api/services/claim-center/ClaimServiceAPI';
import { uploadAttachedDocumentPlaceholder } from '../../../api/services/claim-center/cc-claimdocument/AttachPlaceHolderGateway';
import { NONE } from '../../constants/SelectParamsConst'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import LoadSpinner from '../custom-components/LoadSpinner';
import TemplatesDialogModel from '../modals/TemplatesDialogModel';
import { NO_DOCUMENTS_SELECTED_HEADER, NO_DOCUMENTS_SELECTED_BODY, MAX_DOCUMENTS_SELECTED_HEADER, MAX_DOCUMENTS_SELECTED_BODY, ERROR_DOCUMENTS_SELECTED_HEADER, ERROR_DOCUMENTS_SELECTED_BODY } from '../../constants/AlertConstants';

class AddDocumentModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedDocumentList: [],
            chosenDocumentList: [],
            ignoreProps: false,
            originalList: [],
            documentTypes: [],
            documentsRelatedTo: [],
            documentsCategory: [],
            documentsAddedBy: [],
            retainedDocumentTypes: [],
            retainedDocumentsRelatedTo: [],
            retainedDocumentsCategory: [],
            retainedDocumentsAddedBy: [],
            searchTempValue: '',
            documentFilters: [],
            startDate: '',
            endDate: '',
            isLoading: false,
            loadingText: '',
            selectedStartDate: '',
            selectedEndDate: '',
            displayDocMissingAlertModal: false,
            displayMaxDocsAlertModal: false,
            displayCCErrAlertModal: false,
        }
        this.hideDocModal = this.hideDocModal.bind(this);
        this.handleDocumentKeywordSearch = this.handleDocumentKeywordSearch.bind(this);
        this.filterAttachments = this.filterAttachments.bind(this);
        this.handleCriteriaChange = this.handleCriteriaChange.bind(this);
        this.resetFiltersApplied = this.resetFiltersApplied.bind(this);
        this.reloadDocuments = this.reloadDocuments.bind(this);
        this.handleStartDateFilter = this.handleStartDateFilter.bind(this);
        this.handleEndDateFilter = this.handleEndDateFilter.bind(this);
        this.addDocMissingAlertModal = this.addDocMissingAlertModal.bind(this);
        this.hideDocMissingAlertModal = this.hideDocMissingAlertModal.bind(this);
        this.addMaxDocsAlertModal = this.addMaxDocsAlertModal.bind(this);
        this.hideMaxDocsAlertModal = this.hideMaxDocsAlertModal.bind(this);
        this.hideAlertModal = this.hideAlertModal.bind(this);
    }

    displayAlertModal(modalStateName) {
        this.setState({ [modalStateName]: true });
    }

    hideAlertModal(modalStateName) {
        this.setState({ displayCCErrAlertModal: false });
    }

    addDocMissingAlertModal() {
        this.setState({ displayDocMissingAlertModal: true });
    }
    hideDocMissingAlertModal = () => {
        this.setState({ displayDocMissingAlertModal: false });
    }

    addMaxDocsAlertModal() {
        this.setState({ displayMaxDocsAlertModal: true });
    }
    hideMaxDocsAlertModal = () => {
        this.setState({ displayMaxDocsAlertModal: false });
    }

    hideDocModal() {
        this.props.hideModal();
        console.log('hideModel');
    }

    async handleCriteriaChange(valueObj) {
        if (valueObj.id === 'doctypeId' ||
            valueObj.id === 'relatedTo' ||
            valueObj.id === 'dCategoryId' ||
            valueObj.id === 'addById' ||
            valueObj.id === 'searchByDocumentId') {
            this.filterAttachments(valueObj);
        }
    }

    async handleDocumentKeywordSearch(valueObj) {
        let objValue = valueObj.target.value;
        console.log(objValue);
        this.setState({ searchTempValue: objValue })
        if (valueObj.target.id === 'searchByDocumentId') {
            this.filterAttachments({ id: valueObj.target.id, value: objValue });
        }
    }

    async filterAttachments(valueObj) {
        //Filter by document type, related to, category, added by, document keyword  
        var existingDocumentFilters = this.state.documentFilters;
        var updatedDocumentFilters = [];
        if (existingDocumentFilters.some(val => val.id === valueObj.id)) {
            updatedDocumentFilters = [...existingDocumentFilters].filter((item) => {
                if (item.id === valueObj.id) {
                    item.value = valueObj.value;
                }
                return item;
            });
        } else {

            updatedDocumentFilters =
                this.state.documentFilters.concat({ id: valueObj.id, value: valueObj.value });
        }
        this.setState({ documentFilters: updatedDocumentFilters }, () =>
            //updating the documentList based on the available filters
            this.updateDocumentsList(this.state.documentFilters)
        );
    }
    async updateDocumentsList(filtersList) {
        var originalDocumentsList = this.state.originalList;
        var filteredDocumentsByType = [];
        var filteredDocumentsByRelatedTo = [];
        var filteredDocumentsByCategory = [];
        var filteredDocumentsByAdded = [];
        var filteredDocumentsByStartDateRange = [];
        var filteredDocumentsByEndDateRange = [];
        var filteredDocumentsByDateRange = [];
        var filteredDocumentsByKeyword = [];
        var filteredDocumentsList = [];

        //filter based on document type
        filtersList.some(function (val) {
            if (val.id === 'doctypeId' && val.value.trim() !== 'None') {
                filteredDocumentsByType = [...originalDocumentsList].filter((item) => {
                    if (item.MimeType.toUpperCase().trim().includes(val.value.toUpperCase().trim())) {
                        return item;
                    }return false;
                });
                filteredDocumentsList = filteredDocumentsByType;
            }return false;
        });

        //filter based on related to
        filtersList.some(function (val) {
            if (val.id === 'relatedTo' && val.value.trim() !== 'None') {
                //if related to filter is the only criteria present
                //using original list to filter
                if (filteredDocumentsList.length <= 0) {
                    filteredDocumentsList = originalDocumentsList;
                }
                filteredDocumentsByRelatedTo = [...filteredDocumentsList].filter((item) => {
                    if (item.RelatedTo.toUpperCase().trim().includes(val.value.toUpperCase().trim())) {
                        return item;
                    }return false;
                });
                filteredDocumentsList = filteredDocumentsByRelatedTo;
            }return false;
        });

        //filter based on category
        filtersList.some(function (val) {
            if (val.id === 'dCategoryId' && val.value.trim() !== 'None') {
                //if category filter is the only criteria present
                //using original list to filter
                if (filteredDocumentsList.length <= 0) {
                    filteredDocumentsList = originalDocumentsList;
                }
                filteredDocumentsByCategory = [...filteredDocumentsList].filter((item) => {
                    if (item.Category.toUpperCase().trim() === val.value.toUpperCase().trim()) {
                        return item;
                    }return false;
                });
                filteredDocumentsList = filteredDocumentsByCategory;
            }return false;
        });
        //filter based on added by
        filtersList.some(function (val) {
            if (val.id === 'addById' && val.value.trim() !== 'None') {
                //if added By filter is the only criteria present
                //using original list to filter
                if (filteredDocumentsList.length <= 0) {
                    filteredDocumentsList = originalDocumentsList;
                }
                filteredDocumentsByAdded = [...filteredDocumentsList].filter((item) => {
                    if (item.AddedBy.toUpperCase().trim() === val.value.toUpperCase().trim()) {
                        return item;
                    }return false;
                });
                filteredDocumentsList = filteredDocumentsByAdded;
            }return false;
        });
        
        //filter based on start date range
        //if start date filter is the only criteria present

        //get the date range first
        var getStartDate = '';
        var getEndDate = '';

        filtersList.some(function (val) {
            if (val.id === 'startDate' && val.value !== '') {
                getStartDate = val.value;
            }
            if (val.id === 'endDate' && val.value !== '') {
                getEndDate = val.value;
            }return false;
        });

        // if start date range is present
        if (getStartDate !== '' && getEndDate === '') {
            //using original list to filter
            if (filteredDocumentsList.length <= 0) {
                filteredDocumentsList = originalDocumentsList;
            }
            var startDate = new Date(getStartDate);
            filteredDocumentsByStartDateRange = [...filteredDocumentsList].filter((item) => {
                var documentDate = new Date(item.AddedDate);
                if (item.AddedDate !== undefined) {
                    if (documentDate.getTime() >= startDate.getTime()) {
                        return item;
                    }
                }return false;
            });
            filteredDocumentsList = filteredDocumentsByStartDateRange;
        }

        // if end date range is present

        if (getEndDate !== '' && getStartDate === '') {
            //using original list to filter
            if (filteredDocumentsList.length <= 0) {
                filteredDocumentsList = originalDocumentsList;
            }
            var endDate = new Date(getEndDate);
            filteredDocumentsByEndDateRange = [...filteredDocumentsList].filter((item) => {

                if (item.AddedDate !== undefined) {
                    var documentDate = new Date(item.AddedDate);
                    if (documentDate.getTime() <= endDate.getTime()) {
                        return item;
                    }
                }return false;
            });
            filteredDocumentsList = filteredDocumentsByEndDateRange;
        }

        //filter documents by date range if available

        if (getStartDate !== '' && getEndDate !== '') {
            var startDateRange = new Date(getStartDate);
            var endDateRange = new Date(getEndDate);
            filteredDocumentsByDateRange = [...filteredDocumentsList].filter((item) => {
                var documentDate = new Date(item.AddedDate);
                if (item.AddedDate !== undefined) {
                    if ((documentDate.getTime() >= startDateRange.getTime()) && (documentDate.getTime() <= endDateRange.getTime())) {
                        return item;
                    }
                }return false;
            });
            filteredDocumentsList = filteredDocumentsByDateRange;
        }

        //using original list to filter when no filters are applied
        var isStartDateCriteria = false;
        var isEndDateCriteria = false;
        var isKeywordSearchCriteria = false;
        var isDocumentTypeCriteria = false;
        var isRelatedToCriteria = false;
        var isCategoryCriteria = false;
        var isAddedByCriteria = false;

        for (var filter of filtersList) {
            if (filter.id === 'searchByDocumentId' && filter.value !== '') {
                isKeywordSearchCriteria = true;
            }
            if (filter.id === 'doctypeId' && filter.value !== 'None') {
                isDocumentTypeCriteria = true;
            }
            if (filter.id === 'relatedTo' && filter.value !== 'None') {
                isRelatedToCriteria = true;
            }
            if (filter.id === 'dCategoryId' && filter.value !== 'None') {
                isCategoryCriteria = true;
            }
            if (filter.id === 'addById' && filter.value !== 'None') {
                isAddedByCriteria = true;
            }
            if (filter.id === 'startDate' && filter.value !== '') {
                isStartDateCriteria = true;
            }
            if (filter.id === 'endDate' && filter.value !== '') {
                isEndDateCriteria = true;
            }
        }

        if (!isKeywordSearchCriteria && !isDocumentTypeCriteria &&
            !isRelatedToCriteria && !isCategoryCriteria &&
            !isAddedByCriteria && !isStartDateCriteria && !isEndDateCriteria) {
            filteredDocumentsList = originalDocumentsList;
        }

        //filter based on template keywords
        filtersList.some(function (val) {
            if (val.id === 'searchByDocumentId') {
                //if keyword filter is the only criteria present
                if (!isDocumentTypeCriteria &&
                    !isRelatedToCriteria && !isCategoryCriteria &&
                    !isAddedByCriteria && !isStartDateCriteria && !isEndDateCriteria) {
                    filteredDocumentsList = originalDocumentsList;
                }

                filteredDocumentsByKeyword = [...filteredDocumentsList].filter((item) => {
                    if ((item.Name !== undefined && item.Name.toLowerCase().trim().includes(val.value.toLowerCase().trim())) ||
                        (item.MimeType !== undefined && item.MimeType.toLowerCase().trim().includes(val.value.toLowerCase().trim())) ||
                        (item.Description !== undefined && item.Description.toLowerCase().trim().includes(val.value.toLowerCase().trim())) ||
                        (item.Category !== undefined && item.Category.toLowerCase().trim().includes(val.value.toLowerCase().trim())) ||
                        (item.AddedBy !== undefined && item.AddedBy.toLowerCase().trim().includes(val.value.toLowerCase().trim())) ||
                        (item.AddedDate !== undefined && item.AddedDate.toLowerCase().trim().includes(val.value.toLowerCase().trim()))) {
                        return item;
                    }return false;
                });
                filteredDocumentsList = filteredDocumentsByKeyword;
            }return false;
        });

        //check if no filters are applied, original documents list is returned

        //return final filtereddocuments to component
        console.log('documents count on screen:' + filteredDocumentsList.length);
        //filter out the documents already present in chosen attachments list
        var chosenDocumentsArr = this.state.chosenDocumentList;
        var chosenResourceIdArr = [];
        if (chosenDocumentsArr.length >= 1) {
            for (var document of chosenDocumentsArr) {
                chosenResourceIdArr.push(document.DocUID);
            }
            filteredDocumentsList = [...filteredDocumentsList].filter((document) => {
                if (!chosenResourceIdArr.includes(document.DocUID)) {
                    return document;
                }return false;
            });
        }
        this.setState({ selectedDocumentList: filteredDocumentsList });
    }

    async resetFiltersApplied() {
        this.setState({
            documentTypes: [], documentsRelatedTo: [], documentsCategory: [], documentsAddedBy: [],
            searchTempValue: '', documentFilters: [], startDate: '',
            endDate: ''
        }, () => {
            this.setState({
                documentTypes: this.state.retainedDocumentTypes, documentsRelatedTo: this.state.retainedDocumentsRelatedTo,
                documentsCategory: this.state.retainedDocumentsCategory, documentsAddedBy: this.state.retainedDocumentsAddedBy,
                searchTempValue: '', documentFilters: [], startDate: '',
                endDate: '', selectedDocumentList: this.state.originalList
            });
        }
        );
        console.log("Invoking reset to default documents filter criteria");
    }

    handleStartDateFilter(date) {
        var selectedStartDate = '';
        if (date !== null) {
            selectedStartDate = date;
        }

        this.setState({
            startDate: date,
            selectedStartDate: selectedStartDate
        });

        this.filterAttachments({ id: 'startDate', value: selectedStartDate });

    };

    handleEndDateFilter(date) {
        var selectedEndDate = '';
        if (date !== null) {
            selectedEndDate = date;
        }
        this.setState({
            endDate: date,
            selectedEndDate: selectedEndDate
        });
        this.filterAttachments({ id: 'endDate', value: selectedEndDate });
    };

    async getDocumentsFromAPI() {
        let response = await getDocuments(this.props.claimNumber, this.props.senderId);
        let updateResponse = response.filter(({ DocUID: id1 }) => !this.props.selectedDocs.some(({ DocUID: id2 }) => id2 === id1));

        //default all filter dropdown criteria values
        var documentTypes = [{ 'id': NONE, 'displayName': '-Select-', 'selected': true }];
        var documentsRelatedTo = [{ 'id': NONE, 'displayName': '-Select-', 'selected': true }];
        var documentsCategory = [{ 'id': NONE, 'displayName': '-Select-', 'selected': true }];
        var documentsAddedBy = [{ 'id': NONE, 'displayName': '-Select-', 'selected': true }];

        for (var document of updateResponse) {

            //get unique document types
            const documentType = document["MimeType"];
            if (documentType !== undefined || documentType !== '') {
                //filter documentType to document extention only
                let documentTypeVal = documentType.slice(documentType.indexOf("/") + 1, documentType.length).toUpperCase();
                if (documentTypeVal !== undefined || documentTypeVal !== '') {
                    if (!documentTypes.some(item => item.id === documentTypeVal)) {
                        documentTypes.push({ 'id': documentTypeVal, 'displayName': documentTypeVal, 'selected': false });
                    }
                }
            }


            //get unique relatedTo values
            const documentRelatedTo = document["RelatedTo"];
            if (documentRelatedTo !== undefined && !documentsRelatedTo.some(item => item.id === documentRelatedTo)) {
                documentsRelatedTo.push({ 'id': documentRelatedTo, 'displayName': documentRelatedTo, 'selected': false });
            }

            //get unique categories
            const documentCategory = document["Category"];
            if (documentCategory !== undefined && !documentsCategory.some(item => item.id === documentCategory)) {
                documentsCategory.push({ 'id': documentCategory, 'displayName': documentCategory, 'selected': false });
            }

            //get unique added by values
            const documentAddedBy = document["AddedBy"];
            if (documentAddedBy !== undefined && !documentsAddedBy.some(item => item.id === documentAddedBy)) {
                documentsAddedBy.push({ 'id': documentAddedBy, 'displayName': documentAddedBy, 'selected': false });
            }
        }

        this.setState({
            selectedDocumentList: updateResponse, originalList: updateResponse, chosenDocumentList: this.props.selectedDocs,
            documentTypes: documentTypes, documentsRelatedTo: documentsRelatedTo,
            documentsCategory: documentsCategory, documentsAddedBy: documentsAddedBy,
            retainedDocumentTypes: documentTypes, retainedDocumentsRelatedTo: documentsRelatedTo,
            retainedDocumentsCategory: documentsCategory, retainedDocumentsAddedBy: documentsAddedBy, isLoading: false
        });
    }

    async reloadDocuments() {
        this.setState({ isLoading: true, loadingText: 'Refreshing...' });
        console.log('Refreshing: ' + this.state.isLoading);
        try {
            this.getDocumentsFromAPI();
            //reset the filter applied if any
            this.resetFiltersApplied();
        } catch (error) {
            this.props.isException();
        }
    }

    embbedTemplate() {
        console.log("calling")
        // Atleast one document need to selected else user need to close the window
        if (this.state.chosenDocumentList.length > 0) {
            this.props.updateAttachments(this.props.attachTempId, this.state.chosenDocumentList);
            this.hideDocModal();
        } else {
            this.addDocMissingAlertModal();
        }

    }

    async addSelection(document) {
        this.setState({ isLoading: true, loadingText: 'Selecting...' });
        //Per E1PCSFCC-277 - Maximum allowed documents is 5
        if (this.state.chosenDocumentList.length > 4) {
            this.addMaxDocsAlertModal();
        } else {
            let status = await uploadAttachedDocumentPlaceholder(document.ID);
            if (status === 'Success') {
                var newChosenData = this.state.chosenDocumentList.concat(document);
                let index = this.state.selectedDocumentList.map(x => {
                    return x.DocUID;
                }).indexOf(document.DocUID);
                console.log("Index: " + index);
                var newSelectData = this.state.selectedDocumentList;
                newSelectData.splice(index, 1);
                this.setState({ chosenDocumentList: newChosenData, selectedDocumentList: newSelectData, ignoreProps: true })
                //this.props.handleChange({ id: this.props.id, value: newChosenData });
            } else {
                this.displayAlertModal('displayCCErrAlertModal');
            }
        }
        this.setState({ isLoading: false });

    }

    removeSelection(document) {
        var newSelectData = this.state.selectedDocumentList.concat(document);
        let index = this.state.chosenDocumentList.map(x => {
            return x.DocUID;
        }).indexOf(document.DocUID);
        var newChosenData = this.state.chosenDocumentList;
        newChosenData.splice(index, 1)
        this.setState({ selectedDocumentList: newSelectData, chosenDocumentList: newChosenData, ignoreProps: true })
    }

    renderTableData() {
        return this.state.selectedDocumentList ? this.state.selectedDocumentList.map((document, index) => {
            var documentTypeVal = document.MimeType.slice(document.MimeType.indexOf("/") + 1, document.MimeType.length).toUpperCase();
            return (
                <tr key={index} data-label={index}>
                    <td data-label="select" className='select'>
                        <div className="content" id={document.ID}>
                            <div className='icon-plus-thick templateSelect' onClick={this.addSelection.bind(this, document)} ></div>
                        </div>
                    </td>
                    <td data-label="documentName" className='documentName'>
                        <div className="content">
                            {document.Name}
                        </div>
                    </td>
                    <td data-label="type" className='documentType documentTypeSelect'>
                        <div className="type">
                            {documentTypeVal}
                        </div>
                    </td>
                    <td data-label="description" className='documentDescription documentDescriptionSelect'>
                        <div className="content">
                            {document.Description}
                        </div>
                    </td>
                    <td data-label="category" className='documentCategory documentCategorySelect'>
                        <div className="content">
                            {document.Category}
                        </div>
                    </td>
                    <td data-label="addedBy" className='documentAddedBy documentAddedBySelect'>
                        <div className="content">
                            {document.AddedBy}
                        </div>
                    </td>
                    <td data-label="dateAdded" className='documentDateAdded documentDateAddedSelect'>
                        <div className="content">
                            {document.AddedDate}
                        </div>
                    </td>
                </tr>)
        }) : '';
    }

    renderChosenData() {
        return this.state.chosenDocumentList != null ? this.state.chosenDocumentList.map((document, index) => {
            return (
                <tr key={index}>
                    <td data-label="remove" className='remove'>
                        <div className="content">
                            <div className='icon-delete templateSelect' onClick={this.removeSelection.bind(this, document)}></div>
                        </div>
                    </td>
                    <td data-label="DocumentName" className='selectedDocumentName'>
                        <div className="content">
                            {document.Name}
                        </div>
                    </td>
                </tr>)
        }) : '';

    }


    componentWillUnmount() {
        console.log("END");
    }

    async componentDidMount() {
        console.log("START");
        console.log(this.props.selectedDocs);
        //calling documents api to fetch document
        this.getDocumentsFromAPI();
    }

    render() {
        const CustomInputStartDate = ({ value, onChange, onClick }) => (
            <div className="input">
                <input type="search" id="dateStart" value={value} onChange={onChange} onClick={onClick} className="icon fill" /><span className="icon-calendar" />
                <label htmlFor="dateStart">
                    Date Range: Start
                            </label>
            </div>

        );

        const CustomInputEndDate = ({ value, onChange, onClick }) => (
            <div className="input">
                <input type="search" id="dateEnd" value={value} onChange={onChange} onClick={onClick} className="icon fill" /><span className="icon-calendar" />
                <label htmlFor="dateEnd">
                    Date Range: End
                            </label>
            </div>

        );
        return (
            <div className='overlay-black modal-back-hide'>
                <div className='doc-modal-container center'>
                    <div className="bg-light-gray doc-heading-bg">
                        <div className='doc-heading weight-semibold'>Add/Remove Attachments</div>
                    </div>
                    <div className="input-group column d-doc-search">
                        <div className="input">
                            <input type="search" id="searchByDocumentId" onChange={this.handleDocumentKeywordSearch} value={this.state.searchTempValue} className="icon fill" /><span className="icon-search-compass" />
                            <label htmlFor="input-doc">
                                Search
                            </label>
                        </div>
                    </div>
                    <div className="input-group column d-doc-type">
                        <DropDown id='doctypeId' optionData={this.state.documentTypes} Title={'Document Type'} handleChange={this.handleCriteriaChange}
                            filterAttachments={this.filterAttachments} />
                    </div>
                    <div className="input-group column d-related-to">
                        <DropDown id='relatedTo' optionData={this.state.documentsRelatedTo} Title={'Related To'} handleChange={this.handleCriteriaChange}
                            filterAttachments={this.filterAttachments} />
                    </div>
                    <div className="input-group column d-category">
                        <DropDown id='dCategoryId' optionData={this.state.documentsCategory} Title={'Category'} handleChange={this.handleCriteriaChange}
                            filterAttachments={this.filterAttachments} />
                    </div>
                    <div className="input-group column d-added-by">
                        <DropDown id='addById' optionData={this.state.documentsAddedBy} Title={'Added By'} handleChange={this.handleCriteriaChange}
                            filterAttachments={this.filterAttachments} />
                    </div>
                    <div className="input-group column d-date-start">
                        <DatePicker
                            selected={this.state.startDate}
                            onChange={this.handleStartDateFilter}
                            customInput={<CustomInputStartDate />}
                        />
                    </div>
                    <div className="input-group column d-date-end">
                        <DatePicker
                            selected={this.state.endDate}
                            onChange={this.handleEndDateFilter}
                            customInput={<CustomInputEndDate />}
                        />
                    </div>
                    <div className="input-group column d-reset-filter">
                        <button className='outline white' onClick={this.resetFiltersApplied}>Reset&nbsp;Filters</button>
                    </div>
                    <div className="d-select-heading heading-section">
                        Select Attachments
                    </div>
                    <div className='d-refresh'>
                        <button className="outline white icon-refresh-reset" onClick={this.reloadDocuments}> Refresh</button>
                    </div>
                    <div className='d-select-Border' />
                    <table className="stripe fill doc-tableDocuments hideScroll">
                        <thead className=''>
                            <tr>
                                <th className='select'>Select</th>
                                <th className='documentName'>Document Name</th>
                                <th className='documentType'>Type</th>
                                <th className='documentDescription'>Description</th>
                                <th className='documentCategory'>Category</th>
                                <th className='documentAddedBy'>Added By</th>
                                <th className='documentDateAdded'>Date Added</th>
                            </tr>
                        </thead>
                        <tbody className=''>{this.renderTableData()}</tbody>
                    </table>
                    <div>
                        <div className="d-chosen-heading heading-section">
                            Chosen&nbsp;Attachments
                </div>
                        <div className='d-chosen-Border' />
                        <table className="stripe fill d-tableChoosen hideScroll">
                            <thead>
                                <tr>
                                    <th className='remove'>Remove</th>
                                    <th className='selectedDocumentName'>Document&nbsp;Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.renderChosenData()}
                            </tbody>
                        </table>
                        <div className='d-select-fBorder' />
                    </div>
                    <button onClick={this.hideDocModal.bind(this)} className='bg-light-gray close-btn icon-times-thick'></button>
                    <button className='add-btn' onClick={this.embbedTemplate.bind(this)}>Add to Template</button>

                </div>
                <LoadSpinner isLoading={this.state.isLoading} contentText={this.state.loadingText} />
                {this.state.displayDocMissingAlertModal ? <TemplatesDialogModel headerContent={NO_DOCUMENTS_SELECTED_HEADER} bodyContent={NO_DOCUMENTS_SELECTED_BODY} hideTemplateAlertModal={this.hideDocMissingAlertModal} /> : null}
                {this.state.displayMaxDocsAlertModal ? <TemplatesDialogModel headerContent={MAX_DOCUMENTS_SELECTED_HEADER} bodyContent={MAX_DOCUMENTS_SELECTED_BODY} hideTemplateAlertModal={this.hideMaxDocsAlertModal} /> : null}
                {this.state.displayCCErrAlertModal ? <TemplatesDialogModel headerContent={ERROR_DOCUMENTS_SELECTED_HEADER} bodyContent={ERROR_DOCUMENTS_SELECTED_BODY} hideTemplateAlertModal={this.hideAlertModal} /> : null}

            </div>
        );

    }

}

export default AddDocumentModal;
