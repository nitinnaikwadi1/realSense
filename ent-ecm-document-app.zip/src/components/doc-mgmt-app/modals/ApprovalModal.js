import React from 'react';
import Iframe from 'react-iframe';
import TemplatesDialogModel from './TemplatesDialogModel';

import { REQUIRED_HEADER, REQUIRED_BODY, APPROVED_MSG, REJECTED_MSG, ERROR } from '../../constants/AlertConstants';
import { SC_SSO, SC_URL } from '../../constants/GlobalConstants';

import { invokeProcessDocument } from '../../../api/services/claim-center/cc-claimdocument/ProcessDocGateway';
import '../../../assets/css/approval-model.css';



class ApprovalModal extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            reviewComments: '',
            action: '',
            show: true,
            displayTemplateAlertModal: false,
            isDisplayBanner: false,
            displayAuthorityAlertModal: false,
            authorityAlertMessage: '',
        }
        this.handleReject = this.handleReject.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleApproval = this.handleApproval.bind(this);
        this.processDocument = this.processDocument.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.addTemplateAlertModal = this.addTemplateAlertModal.bind(this);
        this.hideTemplateAlertModal = this.hideTemplateAlertModal.bind(this);
        this.addAuthorityAlertModal = this.addAuthorityAlertModal.bind(this);
        this.hideAuthorityAlertModal = this.hideAuthorityAlertModal.bind(this);
    }

    addTemplateAlertModal() {
        this.setState({ displayTemplateAlertModal: true });
    }
    hideTemplateAlertModal = () => {
        this.setState({ displayTemplateAlertModal: false });
    }

    addAuthorityAlertModal() {
        this.setState({ displayAuthorityAlertModal: true });
    }
    
    hideAuthorityAlertModal = () => {
        this.setState({ displayAuthorityAlertModal: false });
    }

    enableButtons() {

    }

    handleChange(e) {
        this.setState({ reviewComments: e.target.value })
    }

    handleApproval() {
        this.setState({ action: 'Approved' })
        this.getReviewString(this.processDocument, true);
    }

    handleReject() {
        this.setState({ action: 'Rejected' })
        this.getReviewString(this.processDocument, true);
    }

    closeModal(isCompleted) {
        this.setState({ show: false, isDisplayBanner: true });
    }


    getReviewString(callback, isFinalized) {
        console.log("getReviewString:" + isFinalized)
        var editor = document.getElementById('draftEditorId').contentWindow.getEditor();
        editor.getString(function (success, reviewCase) {
            if (success && reviewCase) {
                console.log("getReviewString:success" + success)
                if (isFinalized) {
                    var options = {
                        includeUnselectedChoices: false
                    };
                    editor.findString('#REQUIRED', options, function (success, returnValue) {
                        if (returnValue.totalFound === 0) {
                            callback(reviewCase, true);
                        } else {
                            callback(reviewCase, false);
                            alert('Please update the required or invalid fields in the document.\n (NOTE: Value of #REQUIRED is not allowed.)');
                        }
                    });
                } else {
                    callback(reviewCase, true);
                }
            }
            else if (success) {
                //Need to be fixed later using callback
                return 'Failed to return te draft as a string';
            }
            else {
                //Need to be fixed later using callback
                return 'API Call timed out';
            }
        });
    }

    async processDocument(reviewCase, isSuccess) {

        if (isSuccess) {
            try {
                let result = await invokeProcessDocument(this.props.claimNumber, reviewCase, this.props.docPublicID, '', '', this.props.approverId, true, '', this.state.action, '', this.state.reviewComments, '', '', '', '');
                console.log(result);
                
                if (result.status === 'Error') {
                    this.setState({authorityAlertMessage : result.messages[0].message},()=>{
                        this.addAuthorityAlertModal();
                    });
                }

                if (result === 'Success') {
                    console.log("Document Generation flow completed!");
                    this.closeModal();
                }
                console.log('DONE');
            } catch (error) {
                this.props.updateException();
            }
        } else {
            this.addTemplateAlertModal();
        }


    }

    renderEditor() {
        var draftString = this.props.draftString;
        document.getElementById('draftEditorId').contentWindow.renderDraftEditor(draftString, this.enableButtons, SC_SSO, SC_URL, []);
    }

    render() {
        if (this.state.show) {
            return (
                <div className='a-modal'>
                    <div className='a-modal-container'>
                        <Iframe url="drafteditor.html"
                            id="draftEditorId"
                            className="a-editor-container"
                            display="initial"
                            position="relative"
                            onLoad={this.renderEditor.bind(this)} />
                        <div className='review-text'>Review</div>
                        <div className='review-border'></div>
                        <div>
                            <label className='label-comments'>Review Comments <span className='required'>*</span></label>
                            <textarea id="textarea-comments" maxLength="1333" placeholder='Only required to reject a documents' value={this.state.reviewComments} onChange={this.handleChange}></textarea>
                        </div>
                        <button className='a-reject-btn' disabled={!this.state.reviewComments} onClick={this.handleReject}>Reject</button>
                        <button className='a-approval-btn' onClick={this.handleApproval}>Approve</button>
                    </div>
                    {this.state.displayTemplateAlertModal ? <TemplatesDialogModel headerContent={REQUIRED_HEADER} bodyContent={REQUIRED_BODY} hideTemplateAlertModal={this.hideTemplateAlertModal} /> : null}
                    {this.state.displayAuthorityAlertModal ? <TemplatesDialogModel headerContent={ERROR} bodyContent={this.state.authorityAlertMessage} hideTemplateAlertModal={this.hideAuthorityAlertModal} /> : null}
                </div>
            );
        } else {
            return (<div>
                <DisplayAlert isDisplayBanner={this.state.isDisplayBanner} action={this.state.action} />
            </div>);
        }
    }

}

function DisplayAlert(props) {
    console.log(props.isDisplayBanner);
    if (props.isDisplayBanner) {
        let message = props.action === 'Approved' ? APPROVED_MSG : REJECTED_MSG;
        console.log(message);
        return (<div className='r-complete-banner'>
            <span className='r-complete-icon icon-star'></span>
            <div className='r-complete-text'>
                {message}
            </div>
        </div>);
    } else {
        console.log("Inside else log");
        return null;
    }
}

export default ApprovalModal;
