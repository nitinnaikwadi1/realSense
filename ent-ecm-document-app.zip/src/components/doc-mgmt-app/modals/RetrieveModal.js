import React from 'react';
import Modal from './Modal';
import '../../../assets/css/modal.css'

import { SAVED_COMPLETED, SAVED_DISCARDED } from '../../constants/AlertConstants';

class RetrieveModal extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            show: false,
            isDisplayBanner: false,
            isCompleted: false,
        }

    }

    showModal = () => {
        this.setState({ show: true });
    }

    // In Approval flow, the hide modal always have banner but content will change
    hideModal = (isCompleted) => {
        console.log(isCompleted);
        this.setState({ show: false, isDisplayBanner: true, isCompleted: isCompleted });
    }

    render() {
        var responseObject = {
            reviewCaseStr: this.props.draftString,
            jobMessages: ''
        };
        console.log(this.props.senderID);
        return (
            <div>
                <DisplayAlert isDisplayBanner={this.state.isDisplayBanner} isCompleted={this.state.isCompleted} />
                <div className='r-modal'>
                    <Modal show={this.state.show} reviewCaseObj={responseObject} isLoadedStr='true' isException={this.props.updateException} hideModal={this.hideModal} action={this.props.action} docPublicID={this.props.docPublicID} claimNumber={this.props.claimNumber} senderID={this.props.senderID} />
                </div>
            </div>);
    }

    componentDidMount() {
        this.setState({ show: true });
    }

}

function DisplayAlert(props) {
    console.log(props.isDisplayBanner);
    if (props.isDisplayBanner) {
        let message = props.isCompleted ? SAVED_COMPLETED : SAVED_DISCARDED;
        console.log(message);
        return (<div className='r-complete-banner'>
            <span className='r-complete-icon icon-star'></span>
            <div className='r-complete-text'>
                {message}
            </div>
        </div>);
    } else {
        console.log("Inside else log");
        return null;
    }
}

export default RetrieveModal;
