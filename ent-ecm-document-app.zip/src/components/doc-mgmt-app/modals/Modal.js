import React from 'react';
import '../../../assets/css/modal.css'
import Iframe from 'react-iframe';
import LoadSpinner from '../custom-components/LoadSpinner';
import ConfirmationModal from './ConfirmationModal';
import Accordion from '../custom-components/Accordion';
import TemplatesDialogModel from './TemplatesDialogModel';

import { REQUIRED_HEADER, REQUIRED_BODY, SMART_COMM_CHOICE_NOT_SELECT_ERROR, SMART_COMM_CHOICE_REQUIRED_HEADER, SMART_COMM_CHOICE_REQUIRED_BODY, CHOICELIST_REQUIRED_BOTH_BODY } from '../../constants/AlertConstants';
import { invokeProcessDocument } from '../../../api/services/claim-center/cc-claimdocument/ProcessDocGateway';
import { cancelDraftDocument } from '../../../api/services/claim-center/cc-claimdocument/CancelDraftDocGateway';
import { SC_SSO, SC_URL } from '../../constants/GlobalConstants';


class Modal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showModal: this.props.show,
            isFinalized: false,
            displayConfirmModal: false,
            displayTemplateAlertModal: false,
            templateAlertModalHeader: '',
            templateAlertModalBody: '',
            isDisableButtons: true,
            isLoadSpinner: true,
        }
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.saveDraft = this.saveDraft.bind(this);
        this.createCorrespondence = this.createCorrespondence.bind(this);
        this.completeDraftOperation = this.completeDraftOperation.bind(this);
        this.saveDraftOperation = this.saveDraftOperation.bind(this);
        this.processDocument = this.processDocument.bind(this);
        this.addConfirmModel = this.addConfirmModel.bind(this);
        this.hideConfirmModal = this.hideConfirmModal.bind(this);
        this.hideConfirmModalAndEditor = this.hideConfirmModalAndEditor.bind(this);
        this.addTemplateAlertModal = this.addTemplateAlertModal.bind(this);
        this.hideTemplateAlertModal = this.hideTemplateAlertModal.bind(this);
        this.enableButtons = this.enableButtons.bind(this);
    }

    enableButtons() {
        console.log("Enabling button...");
        this.setState({ isDisableButtons: false, isLoadSpinner: false });
    }

    addTemplateAlertModal(header, msgContent) {
        this.setState({ displayTemplateAlertModal: true, templateAlertModalHeader: header, templateAlertModalBody: msgContent, isLoadSpinner: false });
    }
    hideTemplateAlertModal() {
        this.setState({ displayTemplateAlertModal: false });
    }

    showModal() {
        this.setState({ show: true });
    }

    saveDraft() {
        this.setState({ isFinalized: false, isLoadSpinner: true });
        this.saveDraftOperation(this.processDocument, false);
    }


    createCorrespondence() {
        this.setState({ isFinalized: true, isLoadSpinner: true });
        this.completeDraftOperation(this.processDocument, true);
    }

    hideModal(isCompleted) {
        console.log('hideModel');
        this.setState({ isLoadSpinner: true, isDisableButtons: true });
        this.props.hideModal(isCompleted, this.state.isFinalized);
    }

    addConfirmModel() {
        this.setState({ displayConfirmModal: true });
    }
    hideConfirmModal = () => {
        this.setState({ displayConfirmModal: false });
    }

    async hideConfirmModalAndEditor() {
        // This check is for the Discard activity of SAVED draft functionality. For general flow docPublicID won't be avaialble.
        if (this.props.docPublicID !== undefined) {
            try {
                console.log("Processing Discard Draft operation:" + this.props.docPublicID);
                let response = await cancelDraftDocument(this.props.docPublicID);;
                console.log(response);
                if (response !== 'Success') {
                    alert("Problem while discarding the draft. Please contact claims support");
                    this.props.isException();
                }
            } catch (error) {
                this.props.isException();
            }
        }
        this.setState({ displayConfirmModal: false, isLoadSpinner: true, isDisableButtons: true });
        this.props.hideModal(false);
    }

    // This need to refactor using DraftEditor.v3 of saveToString() method to avoid multiple calls to SC methods.
    completeDraftOperation(callback, isFinalized) {
        var options = {
            includeUnselectedChoices: false
        };

        // set focus to the draft editor
        document.getElementById('draftEditorId').contentWindow.focus();
        
        var editor = document.getElementById('draftEditorId').contentWindow.getEditor();
        editor.getString(function (success, reviewCase) {
            if (reviewCase === SMART_COMM_CHOICE_NOT_SELECT_ERROR) {
                editor.findString('#REQUIRED', options, function (success, returnValue) {
                    if (returnValue.totalFound !== 0) {
                        callback(reviewCase, false, REQUIRED_HEADER, CHOICELIST_REQUIRED_BOTH_BODY);
                    } else {
                        callback(reviewCase, false, SMART_COMM_CHOICE_REQUIRED_HEADER, SMART_COMM_CHOICE_REQUIRED_BODY);
                    }
                });
            } else {
                if (success && reviewCase) {
                    editor.findString('#REQUIRED', options, function (success, returnValue) {
                        if (returnValue.totalFound === 0) {
                            callback(reviewCase, true);
                        } else {
                            callback(reviewCase, false, REQUIRED_HEADER, REQUIRED_BODY);
                        }
                    });
                }
            }
        });
    }

    saveDraftOperation(callback, isFinalized) {
        var editor = document.getElementById('draftEditorId').contentWindow.getEditor();
        editor.getStringWithoutValidation(function (success, reviewCase) {
            if (success && reviewCase) {
                callback(reviewCase, true);
            }
            else if (success) {
                //Need to be fixed later using callback
                return 'Failed to return te draft as a string';
            }
            else {
                //Need to be fixed later using callback
                return 'API Call timed out';
            }
        });
    }

    async processDocument(reviewCase, isSuccess, header, msgContent) {
        console.log("Inside Here");
        if (isSuccess) {
            try {
                //xmlPayload needs to be passed to process document for actions as well like draft etc.
                var xmlPayload = this.props.xmlPayload;
                if (xmlPayload === undefined) {
                    xmlPayload = this.props.reviewCaseObj.reviewCaseStr;
                }
                let result = await invokeProcessDocument(this.props.claimNumber, reviewCase, this.props.docPublicID, this.props.deliveryType, this.props.senderID, this.props.approverId, this.state.isFinalized, this.props.approvalLevel, this.props.action, this.props.archiveOnly, this.props.reviewComments, this.props.draftID, this.props.respAttachments, this.props.recipientsDataArr, xmlPayload, this.props.selectedTemplatesArr);
                console.log(result);
                if (result === 'Success' && this.state.isFinalized === true) {
                    console.log("Document Generation flow completed!");
                    this.hideModal(true);
                } else if (result === 'Success' && this.state.isFinalized === false) {
                    console.log("Document Generation flow completed!");
                    this.hideModal(true);
                }
                console.log('DONE');
            } catch (error) {
                this.props.isException();
            }
        } else {
            this.addTemplateAlertModal(header, msgContent);
        }
    }

    renderEditor() {

        if (this.props.isLoadedStr) {
            console.log("Loading")
            var reviewCaseStr = this.props.reviewCaseObj.reviewCaseStr;
            console.log("ReviewCase:" + reviewCaseStr);
            console.log("SC_SSO:" + SC_SSO);
            console.log("SC_URL:" + SC_URL);
            console.log("Approval Level: " + this.props.approvalLevel);
            let DISABLE_CONFIG=[];
            if(this.props.approvalLevel > 0 ){
                DISABLE_CONFIG = ['Save', 'Preview'];
            }      
            let isSuccess = document.getElementById('draftEditorId').contentWindow.renderDraftEditor(reviewCaseStr, this.enableButtons, SC_SSO, SC_URL, DISABLE_CONFIG);
            console.log("After renderEditor: " + isSuccess);
        } else {
            console.log("done!!");
        }
    }

    render() {
        //check if error messages presenet
        var isErrorPresent = false;
        const messagesArr = this.props.reviewCaseObj.jobMessages;
        if (messagesArr !== undefined && messagesArr.length > 0) {
            isErrorPresent = true;
        }

        if (this.props.show) {
            return (
                <div className=''>
                    <div className='modal-container overlay-black'>
                        <Iframe url="drafteditor.html"
                            id="draftEditorId"
                            className="editor-container"
                            display="initial"
                            position="absolute"
                            onLoad={this.renderEditor.bind(this)} />
                        <button disabled={this.state.isDisableButtons} onClick={this.addConfirmModel.bind(this)} className='discardBtn'>Discard</button>
                        <button disabled={this.state.isDisableButtons} onClick={this.saveDraft} className='saveDraftBtn'>Save Draft</button>
                        <button disabled={this.state.isDisableButtons} onClick={this.createCorrespondence} className='CreatCrBtn'>Create Correspondence</button>
                    </div>
                    <div>
                        {isErrorPresent ? <Accordion errorInfo={this.props.reviewCaseObj.jobMessages} /> : null}
                    </div>
                    <div>
                        {this.state.displayConfirmModal ? <ConfirmationModal hideConfirmModal={this.hideConfirmModal} hideConfirmModalAndEditor={this.hideConfirmModalAndEditor} /> : null}
                    </div>
                    <div>
                        {this.state.displayTemplateAlertModal ? <TemplatesDialogModel headerContent={this.state.templateAlertModalHeader} bodyContent={this.state.templateAlertModalBody} hideTemplateAlertModal={this.hideTemplateAlertModal} /> : null}
                    </div>
                    <LoadSpinner isLoading={this.state.isLoadSpinner} contentText='Processing...' />
                </div>
            );
        } else if (!this.props.show && this.props.displaySpinner) {
            return (<div>
                <LoadSpinner isLoading={this.props.displaySpinner} contentText='Launching Editor...' />
            </div>)

        }
        else {
            return (<div></div>);
        }

    }

}

export default Modal;
