import React from "react";

import '../../../assets/css/alert-model.css'

class AlertModel extends React.Component {
    render() {
        if (this.props.show) {
            return (
                <div className="alert-container">
                    <div className="box">
                        <div className='f-alert-icon'><span className='icon-alert'/></div>
                        <div className="alert-text">
                            CommLink is currently unavailable.
                            <div className ='c-alert-text'>
                            Please close your browser and try again.
                            If this message persists, please contact the Help Desk.
                            </div> 
                        </div>
                    </div>
                </div>

            );
        } else if (!this.props.show && this.props.displaySpinner) {
            return (<div>
            </div>)

        }
        else {
            return (<div></div>);
        }
    }
}

export default AlertModel;