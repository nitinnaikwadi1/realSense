import React from "react";
import '../../../assets/css/confirm-modal.css'

class ConfirmationModel extends React.Component {
    constructor(props) {
        super(props);
        this.hideConfirmationModal = this.hideConfirmationModal.bind(this);
        this.proceedWithDiscard = this.proceedWithDiscard.bind(this);
    }

    hideConfirmationModal() {
        this.props.hideConfirmModal();
    }

    proceedWithDiscard() {
        this.props.hideConfirmModalAndEditor();
    }

    render() {
            return (
                <div className='overlay-black modal-back-hide'>
                <div className='confirm-modal'>
                        <div className="bg-light-gray msg-heading-bg">
                            <div className='confirm-heading weight-normal'>Are you sure you want to discard the draft correspondence?</div>
                        </div>
                        <div className="confirm-msg weight-semibold">
                        Your correspondence will not be sent.
                        </div>
                    <button onClick={this.hideConfirmationModal.bind(this)} className='bg-light-gray confirm-close-btn  icon-times-thick'></button>
                    <button onClick={this.hideConfirmationModal.bind(this)} className='confirm-no-btn'>CANCEL</button>
                    <button onClick={this.proceedWithDiscard.bind(this)} className='confirm-yes-btn'>DISCARD DRAFT</button>
                </div>
                </div>
            );
    }
}

export default ConfirmationModel;