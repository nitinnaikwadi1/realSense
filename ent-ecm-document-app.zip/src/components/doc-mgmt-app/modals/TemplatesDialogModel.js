import React from "react";
import '../../../assets/css/template-msg-modal.css'

class TemplatesDialogModel extends React.Component {
    constructor(props) {
        super(props);
        this.hideDialog = this.hideDialog.bind(this);
    }

    hideDialog() {
        this.props.hideTemplateAlertModal();
    }

    render() {

            return (
                <div className='overlay-black modal-back-hide'>
                <div className='msg-modal'>
                    <div className="bg-light-gray msg-heading-bg">
                        <div className='msg-heading weight-normal'>{this.props.headerContent}</div>
                    </div>
                        <div className="msg-text weight-semibold hideScroll">
                            {this.props.bodyContent}
                        </div>
                    <button onClick={this.hideDialog.bind(this)} className='bg-light-gray msg-close-btn icon-times-thick'/>
                    <button onClick={this.hideDialog.bind(this)} className='msg-no-btn'>CLOSE</button>
                </div>
                </div>
            );
    }
}

export default TemplatesDialogModel;