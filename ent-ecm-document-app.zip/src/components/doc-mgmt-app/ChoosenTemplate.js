import React from 'react';

class ChoosenTemplate extends React.Component {
    renderTableData() {
        return this.props.templateList != null ? this.props.templateList.map((template, index) => {
            return (
                <tr>
                    <td data-label="remove">
                        <div className="content">
                            <a className='icon-delete'></a>
                        </div>
                    </td>
                    <td data-label="templateName">
                        <div className="content">
                            {template.resourceName}
                        </div>
                    </td>
                </tr>)
        }) : '';

    }

    render() {
        return (
            <div>
                <div id='tSubHeading1' className="heading-section">
                    Select Templates
            </div>
                <div id='tSubHeading2' className="heading-section">
                    Chosen Templates
                </div>
                <div className='tBorder2' />
                <table className="stripe fill tableChoosen">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Template Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.renderTableData()}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default ChoosenTemplate;