import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';

import ValidateSSO from './components/doc-mgmt-app/sso/ValidateSSO';
 
ReactDOM.render(<ValidateSSO/>, document.getElementById('root'));